// TaskFlow Pro - Task Management Desktop App
// Vanilla JavaScript Implementation

// ===================== STATE MANAGEMENT =====================
const AppState = {
    currentRole: 'store-manager',
    theme: 'light',
    language: 'en',
    
    // Data
    tasks: [
        { id: '1', text: 'Check inventory levels', completed: false, isMandatory: true },
        { id: '2', text: 'Review daily sales report', completed: false, isMandatory: true },
        { id: '3', text: 'Verify product displays', completed: false, isMandatory: true },
        { id: '4', text: 'Contact supplier about delivery', completed: false, isMandatory: false },
    ],
    
    notifications: [
        { id: '1', from: 'HQ Admin', message: 'New pricing policy effective next week', type: 'info', date: '2026-01-15', read: false },
        { id: '2', from: 'Product Manager', message: 'Low stock alert: Milk (3 units left)', type: 'warning', date: '2026-01-15', read: false },
        { id: '3', from: 'HR Specialist', message: 'Employee shift change approved', type: 'success', date: '2026-01-14', read: true },
        { id: '4', from: 'Store Manager', message: 'Weekly meeting rescheduled to Friday', type: 'info', date: '2026-01-14', read: false },
        { id: '5', from: 'HQ Admin', message: 'Audit scheduled for next month', type: 'warning', date: '2026-01-13', read: true },
    ],
    
    orders: [
        { id: 'ORD-001', date: '2026-01-15', price: 156.99, status: 'on the way', items: [{ name: 'Organic Coffee', quantity: 2, price: 24.99 }, { name: 'Fresh Bread', quantity: 3, price: 8.99 }] },
        { id: 'ORD-002', date: '2026-01-14', price: 89.50, status: 'delivered', items: [{ name: 'Green Tea Set', quantity: 1, price: 45.00 }, { name: 'Honey', quantity: 2, price: 22.25 }] },
        { id: 'ORD-003', date: '2026-01-13', price: 234.00, status: 'delivered', items: [{ name: 'Premium Olive Oil', quantity: 3, price: 78.00 }] },
        { id: 'ORD-004', date: '2026-01-12', price: 45.99, status: 'returned', items: [{ name: 'Almond Butter', quantity: 2, price: 22.99 }] },
        { id: 'ORD-005', date: '2026-01-11', price: 178.25, status: 'refunded', items: [{ name: 'Protein Bars Pack', quantity: 5, price: 35.65 }] },
        { id: 'ORD-006', date: '2026-01-10', price: 67.80, status: 'late', items: [{ name: 'Rice Crackers', quantity: 4, price: 16.95 }] },
        { id: 'ORD-007', date: '2026-01-09', price: 299.99, status: 'cancelled', items: [{ name: 'Gift Basket Premium', quantity: 1, price: 299.99 }] },
    ],
    
    incidents: [
        { id: 'INC-001', type: 'client-related', clientName: 'John Smith', description: 'Customer complaint about expired product', detailedDescription: 'Customer found expired milk on shelf and requested refund. Product was 3 days past expiration date.', status: 'open', priority: 'high', date: '2026-01-15', history: [{ date: '2026-01-15', action: 'Incident created', by: 'Product Manager' }] },
        { id: 'INC-002', type: 'technical', clientName: 'Maria Garcia', description: 'POS system malfunction', detailedDescription: 'Payment terminal stopped working during peak hours, causing delays.', status: 'in progress', priority: 'medium', date: '2026-01-14', history: [{ date: '2026-01-14', action: 'Incident created', by: 'Store Manager' }, { date: '2026-01-14', action: 'Assigned to IT Support', by: 'HR Specialist' }] },
        { id: 'INC-003', type: 'employee', clientName: 'N/A', description: 'Staff shortage during shift', detailedDescription: 'Two employees called in sick, causing understaffing issues.', status: 'resolved', priority: 'low', date: '2026-01-13', history: [{ date: '2026-01-13', action: 'Incident created', by: 'Store Manager' }, { date: '2026-01-13', action: 'Temporary staff assigned', by: 'HR Specialist' }, { date: '2026-01-14', action: 'Incident resolved', by: 'Store Manager' }] },
        { id: 'INC-004', type: 'product', clientName: 'David Lee', description: 'Product quality issue', detailedDescription: 'Customer reported damaged packaging on premium items.', status: 'open', priority: 'medium', date: '2026-01-15', history: [{ date: '2026-01-15', action: 'Incident created', by: 'Product Manager' }] },
    ],
    
    products: [
        { id: 'P001', name: 'Organic Milk', amount: 3, price: 4.99, category: 'Dairy' },
        { id: 'P002', name: 'Fresh Bread', amount: 2, price: 3.49, category: 'Bakery' },
        { id: 'P003', name: 'Free Range Eggs', amount: 4, price: 6.99, category: 'Dairy' },
        { id: 'P004', name: 'Premium Coffee', amount: 8, price: 12.99, category: 'Beverages' },
        { id: 'P005', name: 'Green Tea', amount: 15, price: 5.99, category: 'Beverages' },
        { id: 'P006', name: 'Olive Oil', amount: 1, price: 15.99, category: 'Pantry' },
        { id: 'P007', name: 'Pasta', amount: 20, price: 2.99, category: 'Pantry' },
        { id: 'P008', name: 'Tomato Sauce', amount: 2, price: 3.49, category: 'Pantry' },
        { id: 'P009', name: 'Chicken Breast', amount: 4, price: 9.99, category: 'Meat' },
        { id: 'P010', name: 'Salmon Fillet', amount: 3, price: 14.99, category: 'Seafood' },
        { id: 'P011', name: 'Greek Yogurt', amount: 2, price: 5.49, category: 'Dairy' },
        { id: 'P012', name: 'Almonds', amount: 6, price: 8.99, category: 'Snacks' },
    ],
    
    stores: [
        { id: 'S001', name: 'Downtown Store', address: '123 Main St', income: 15420, rating: 4.5, auditStatus: 'Passed' },
        { id: 'S002', name: 'Mall Branch', address: '456 Shopping Ave', income: 12850, rating: 4.2, auditStatus: 'Pending' },
        { id: 'S003', name: 'Westside Location', address: '789 West Rd', income: 9340, rating: 4.7, auditStatus: 'Passed' },
        { id: 'S004', name: 'Harbor Store', address: '321 Port Blvd', income: 11200, rating: 4.0, auditStatus: 'Failed' },
        { id: 'S005', name: 'University Branch', address: '555 College Dr', income: 8900, rating: 4.3, auditStatus: 'Passed' },
    ],
    
    employees: [
        { id: 'E001', name: 'Alice Johnson', position: 'Senior Cashier', status: 'active' },
        { id: 'E002', name: 'Bob Williams', position: 'Stock Clerk', status: 'testing' },
        { id: 'E003', name: 'Carol Davis', position: 'Department Manager', status: 'vacation' },
        { id: 'E004', name: 'David Brown', position: 'Cashier', status: 'active' },
        { id: 'E005', name: 'Eva Martinez', position: 'Customer Service', status: 'testing' },
    ],
    
    trainings: [
        { id: 'T001', date: '2026-01-20', theme: 'Customer Service Excellence', participants: 'Bob Williams, Eva Martinez', status: 'planned' },
        { id: 'T002', date: '2026-01-18', theme: 'Product Knowledge Update', participants: 'All Staff', status: 'completed', rating: 4.5 },
        { id: 'T003', date: '2026-01-25', theme: 'Safety Protocols', participants: 'David Brown, Alice Johnson', status: 'planned' },
        { id: 'T004', date: '2026-01-10', theme: 'New POS System Training', participants: 'All Cashiers', status: 'completed', rating: 4.8 },
    ],
    
    orderRequests: [
        { id: 'REQ-001', storeName: 'Downtown Store', productName: 'Organic Milk', amount: 50, status: 'pending', initialDate: '2026-01-15' },
        { id: 'REQ-002', storeName: 'Mall Branch', productName: 'Premium Coffee', amount: 30, status: 'pending', initialDate: '2026-01-14' },
        { id: 'REQ-003', storeName: 'Westside Location', productName: 'Fresh Bread', amount: 40, status: 'approved', comment: 'Approved - delivery in 3 days', initialDate: '2026-01-10', processedDate: '2026-01-12' },
        { id: 'REQ-004', storeName: 'Harbor Store', productName: 'Olive Oil', amount: 25, status: 'denied', comment: 'Budget constraints this month', initialDate: '2026-01-08', processedDate: '2026-01-10' },
        { id: 'REQ-005', storeName: 'Downtown Store', productName: 'Greek Yogurt', amount: 35, status: 'approved', comment: 'Express delivery arranged', initialDate: '2026-01-05', processedDate: '2026-01-06' },
        { id: 'REQ-006', storeName: 'Downtown Store', productName: 'Chicken Breast', amount: 20, status: 'denied', comment: 'Supplier shortage', initialDate: '2026-01-03', processedDate: '2026-01-05' },
        { id: 'REQ-007', storeName: 'Mall Branch', productName: 'Salmon Fillet', amount: 15, status: 'approved', comment: 'Weekly delivery scheduled', initialDate: '2026-01-07', processedDate: '2026-01-09' },
        { id: 'REQ-008', storeName: 'Mall Branch', productName: 'Almonds', amount: 45, status: 'approved', comment: 'Standard approval', initialDate: '2026-01-02', processedDate: '2026-01-04' },
        { id: 'REQ-009', storeName: 'Westside Location', productName: 'Pasta', amount: 60, status: 'denied', comment: 'Exceeded monthly quota', initialDate: '2026-01-04', processedDate: '2026-01-06' },
        { id: 'REQ-010', storeName: 'Harbor Store', productName: 'Tomato Sauce', amount: 30, status: 'approved', comment: 'Rush order approved', initialDate: '2026-01-06', processedDate: '2026-01-07' },
    ],
    
    shifts: [
        { id: 'SH-001', employeeName: 'Alice Johnson', date: '2026-01-16', time: '08:00 - 16:00', position: 'Senior Cashier' },
        { id: 'SH-002', employeeName: 'Bob Williams', date: '2026-01-16', time: '10:00 - 18:00', position: 'Stock Clerk' },
        { id: 'SH-003', employeeName: 'David Brown', date: '2026-01-17', time: '08:00 - 16:00', position: 'Cashier' },
        { id: 'SH-004', employeeName: 'Eva Martinez', date: '2026-01-17', time: '12:00 - 20:00', position: 'Customer Service' },
    ],
    
    employeeShortageRequests: [],
    
    // Page states
    storeManagerPage: 1,
    hrSpecialistPage: 1,
    selectedStore: null,
    selectedOrder: null,
    selectedIncident: null,
    cart: [],
    bonusBalance: 2450,
    useBonuses: false,
    reportSent: false,
    hoveredIncident: null,
    requestComments: {},
    shortageComments: {},
};

// ===================== TRANSLATIONS =====================
const translations = {
    en: {
        appTitle: 'TaskFlow Pro',
        appSubtitle: 'Enterprise Management System',
        quickActions: 'Quick Actions',
        dailyReport: 'Daily Report',
        staffOverview: 'Staff Overview',
        inventoryCheck: 'Inventory Check',
        cashRegister: 'Cash Register',
        viewStoreMetrics: '📈 View Store Metrics & Shifts',
        weeklyIncome: 'Weekly Income Overview',
        dailyRevenue: 'Daily Revenue',
        customersToday: 'Customers Today',
        avgTransaction: 'Avg. Transaction',
        inventoryHealth: 'Inventory Health',
        notifications: 'Notifications & Actions',
        backDashboard: '← Back to Dashboard',
        storeMetrics: 'Store Metrics',
        totalRevenue: 'Total Revenue (Month)',
        avgDailySales: 'Average Daily Sales',
        customerSatisfaction: 'Customer Satisfaction',
        returnRate: 'Return Rate',
        employeeShifts: 'Employee Shifts',
        addShift: '+ Add Shift',
        employee: 'Employee',
        date: 'Date',
        time: 'Time',
        position: 'Position',
        addNewShift: 'Add New Shift',
        employeeName: 'Employee Name',
        cancel: 'Cancel',
        confirm: 'Confirm',
        nearbyStores: 'Nearby Stores Map',
        messagesManagers: 'Messages from Managers',
        storeOverview: 'Store Overview',
        compareStores: '📊 Compare All Stores',
        storeName: 'Store Name',
        todayIncome: "Today's Income",
        rating: 'Rating',
        audit: 'Audit',
        address: 'Address',
        auditStatus: 'Audit Status',
        passed: 'Passed',
        pending: 'Pending',
        failed: 'Failed',
        incomingRequests: 'Incoming Order Requests',
        product: 'Product',
        amount: 'Amount',
        addComment: 'Add comment...',
        deny: 'Deny',
        approve: 'Approve',
        storeComparison: 'Store Performance Comparison',
        close: 'Close',
        selectStore: 'Select Store:',
        employeeChanges: 'Employee Changes - 6 Month Overview',
        hired: 'Hired',
        fired: 'Fired',
        totalEmployees: 'Total Employees',
        testingPeriod: 'Testing Period',
        onVacation: 'On Vacation',
        activeRequests: 'Active Employee Requests',
        vacationRequest: 'Vacation Request',
        shiftChange: 'Shift Change',
        sickLeave: 'Sick Leave',
        trainingRequest: 'Training Request',
        approveCandidates: '📋 Approve Candidates & Handle Incidents',
        complaintsIncidents: 'Complaints & Incidents',
        plannedTrainings: 'Planned Trainings',
        theme: 'Theme',
        participants: 'Participants',
        status: 'Status',
        incidentDetails: 'Incident Details',
        historyChanges: 'History of Changes',
        detailedDescription: 'Detailed Description',
        assignEmployee: 'Assign Employee',
        selectEmployee: 'Select employee...',
        closeIncident: 'Close Incident',
        assign: 'Assign',
        searchProducts: 'Search products...',
        bonusBalance: 'Bonus Balance',
        pts: 'pts',
        quickLinks: 'Quick Links',
        cart: 'Cart',
        orderHistory: 'Order History',
        favorites: 'Favorites',
        coupons: 'Coupons',
        settings: 'Settings',
        recommended: 'Recommended For You',
        addToCart: 'Add to Cart',
        orderUpdates: 'Order Updates',
        myOrders: 'My Orders',
        orderId: 'Order ID',
        price: 'Price',
        actions: 'Actions',
        onTheWay: 'on the way',
        delivered: 'delivered',
        returned: 'returned',
        refunded: 'refunded',
        late: 'late',
        cancelled: 'cancelled',
        reorder: 'Reorder',
        createNewOrder: '+ Create New Order',
        orderDetails: 'Order Details',
        estimatedArrival: 'Estimated Arrival',
        items: 'Items',
        leaveReview: 'Leave a Review',
        submitReview: 'Submit Review',
        refundInfo: 'Refund Information',
        selectOrder: 'Select an order to view details',
        availableProducts: 'Available Products',
        yourCart: 'Your Cart',
        useBonus: 'Use',
        bonusPoints: 'bonus points',
        total: 'Total:',
        paymentInfo: 'Payment Information',
        placeOrder: 'Place Order',
        emptyCart: 'Your cart is empty',
        todoList: 'TODO List',
        addTask: '+ Add',
        addTaskPlaceholder: 'Add new task...',
        required: 'Required',
        sendReport: '📊 Send Daily Report to Store Manager',
        orderProducts: '📦 Order Products',
        reportSent: 'Report sent successfully!',
        lowStock: 'Low Stock Products (<5 units)',
        left: 'left',
        registerIncident: 'Register Incident',
        incidentType: 'Incident Type',
        technical: 'Technical',
        clientRelated: 'Client-related',
        clientNameSurname: 'Client Name & Surname',
        enterClientName: 'Enter client name (if applicable)',
        shortDescription: 'Short Description',
        briefDescription: 'Brief description',
        fullDetails: 'Full details of the incident',
        attachFiles: '📎 Attach Files (UI Only)',
        registerIncidentBtn: 'Register Incident',
        incidentHistory: 'Incident History (This Month)',
        open: 'Open',
        resolved: 'Resolved',
        inProgress: 'In Progress',
        selectProduct: 'Select product...',
        sendRequest: 'Send Request',
        employeeShortage: '👥 Request Employee Recruitment',
        recruitmentRequest: 'Employee Recruitment Request',
        employeeRole: 'Employee Role',
        enterRole: 'Enter role (e.g., Cashier)',
        workersNeeded: 'Number of Workers Needed',
        neededBy: 'Needed By',
        processTimeComparison: 'Order Processing Time Comparison',
        comparePeriod: 'Compare Period',
        pastMonth: 'Past Month',
        allTime: 'All Time',
        avgProcessTime: 'Avg. Process Time',
        days: 'days',
        orderRequestComparison: '📊 Compare Request Processing Time',
        employeeShortageRequests: 'Employee Shortage Requests',
        process: 'Process',
        comment: 'Comment',
    },
    ru: {
        appTitle: 'TaskFlow Pro',
        appSubtitle: 'Система управления предприятием',
        quickActions: 'Быстрые действия',
        dailyReport: 'Дневной отчёт',
        staffOverview: 'Обзор персонала',
        inventoryCheck: 'Проверка запасов',
        cashRegister: 'Касса',
        viewStoreMetrics: '📈 Метрики магазина и смены',
        weeklyIncome: 'Обзор недельного дохода',
        dailyRevenue: 'Дневная выручка',
        customersToday: 'Клиентов сегодня',
        avgTransaction: 'Ср. транзакция',
        inventoryHealth: 'Состояние запасов',
        notifications: 'Уведомления и действия',
        backDashboard: '← Назад к панели',
        storeMetrics: 'Метрики магазина',
        totalRevenue: 'Выручка за месяц',
        avgDailySales: 'Ср. дневные продажи',
        customerSatisfaction: 'Удовлетворённость',
        returnRate: 'Процент возвратов',
        employeeShifts: 'Смены сотрудников',
        addShift: '+ Добавить смену',
        employee: 'Сотрудник',
        date: 'Дата',
        time: 'Время',
        position: 'Должность',
        addNewShift: 'Добавить новую смену',
        employeeName: 'Имя сотрудника',
        cancel: 'Отмена',
        confirm: 'Подтвердить',
        nearbyStores: 'Карта магазинов поблизости',
        messagesManagers: 'Сообщения от менеджеров',
        storeOverview: 'Обзор магазинов',
        compareStores: '📊 Сравнить все магазины',
        storeName: 'Название магазина',
        todayIncome: 'Доход сегодня',
        rating: 'Рейтинг',
        audit: 'Аудит',
        address: 'Адрес',
        auditStatus: 'Статус аудита',
        passed: 'Пройден',
        pending: 'На рассмотрении',
        failed: 'Не пройден',
        incomingRequests: 'Входящие запросы на заказ',
        product: 'Продукт',
        amount: 'Количество',
        addComment: 'Добавить комментарий...',
        deny: 'Отклонить',
        approve: 'Одобрить',
        storeComparison: 'Сравнение производительности магазинов',
        close: 'Закрыть',
        selectStore: 'Выберите магазин:',
        employeeChanges: 'Изменения персонала - Обзор за 6 месяцев',
        hired: 'Нанято',
        fired: 'Уволено',
        totalEmployees: 'Всего сотрудников',
        testingPeriod: 'На испытательном',
        onVacation: 'В отпуске',
        activeRequests: 'Активные запросы сотрудников',
        vacationRequest: 'Запрос на отпуск',
        shiftChange: 'Смена смены',
        sickLeave: 'Больничный',
        trainingRequest: 'Запрос на обучение',
        approveCandidates: '📋 Одобрить кандидатов и инциденты',
        complaintsIncidents: 'Жалобы и инциденты',
        plannedTrainings: 'Запланированные обучения',
        theme: 'Тема',
        participants: 'Участники',
        status: 'Статус',
        incidentDetails: 'Детали инцидента',
        historyChanges: 'История изменений',
        detailedDescription: 'Подробное описание',
        assignEmployee: 'Назначить сотрудника',
        selectEmployee: 'Выберите сотрудника...',
        closeIncident: 'Закрыть инцидент',
        assign: 'Назначить',
        searchProducts: 'Поиск продуктов...',
        bonusBalance: 'Бонусный баланс',
        pts: 'баллов',
        quickLinks: 'Быстрые ссылки',
        cart: 'Корзина',
        orderHistory: 'История заказов',
        favorites: 'Избранное',
        coupons: 'Купоны',
        settings: 'Настройки',
        recommended: 'Рекомендуем',
        addToCart: 'В корзину',
        orderUpdates: 'Обновления заказов',
        myOrders: 'Мои заказы',
        orderId: 'ID заказа',
        price: 'Цена',
        actions: 'Действия',
        onTheWay: 'в пути',
        delivered: 'доставлен',
        returned: 'возвращён',
        refunded: 'возврат средств',
        late: 'задержка',
        cancelled: 'отменён',
        reorder: 'Повторить',
        createNewOrder: '+ Создать новый заказ',
        orderDetails: 'Детали заказа',
        estimatedArrival: 'Ожидаемое прибытие',
        items: 'Товары',
        leaveReview: 'Оставить отзыв',
        submitReview: 'Отправить отзыв',
        refundInfo: 'Информация о возврате',
        selectOrder: 'Выберите заказ для просмотра',
        availableProducts: 'Доступные продукты',
        yourCart: 'Ваша корзина',
        useBonus: 'Использовать',
        bonusPoints: 'бонусных баллов',
        total: 'Итого:',
        paymentInfo: 'Информация об оплате',
        placeOrder: 'Оформить заказ',
        emptyCart: 'Ваша корзина пуста',
        todoList: 'Список задач',
        addTask: '+ Добавить',
        addTaskPlaceholder: 'Добавить новую задачу...',
        required: 'Обязательно',
        sendReport: '📊 Отправить дневной отчёт менеджеру',
        orderProducts: '📦 Заказать продукты',
        reportSent: 'Отчёт успешно отправлен!',
        lowStock: 'Продукты с низким запасом (<5 шт)',
        left: 'осталось',
        registerIncident: 'Регистрация инцидента',
        incidentType: 'Тип инцидента',
        technical: 'Технический',
        clientRelated: 'Связанный с клиентом',
        clientNameSurname: 'Имя и фамилия клиента',
        enterClientName: 'Введите имя клиента (если применимо)',
        shortDescription: 'Краткое описание',
        briefDescription: 'Краткое описание',
        fullDetails: 'Полные детали инцидента',
        attachFiles: '📎 Прикрепить файлы (UI)',
        registerIncidentBtn: 'Зарегистрировать инцидент',
        incidentHistory: 'История инцидентов (этот месяц)',
        open: 'Открыт',
        resolved: 'Решён',
        inProgress: 'В процессе',
        selectProduct: 'Выберите продукт...',
        sendRequest: 'Отправить запрос',
        employeeShortage: '👥 Запрос на найм сотрудников',
        recruitmentRequest: 'Запрос на найм сотрудников',
        employeeRole: 'Должность сотрудника',
        enterRole: 'Введите должность (напр., Кассир)',
        workersNeeded: 'Требуется сотрудников',
        neededBy: 'Требуется к',
        processTimeComparison: 'Сравнение времени обработки заказов',
        comparePeriod: 'Период сравнения',
        pastMonth: 'За месяц',
        allTime: 'За всё время',
        avgProcessTime: 'Ср. время обработки',
        days: 'дней',
        orderRequestComparison: '📊 Сравнить время обработки',
        employeeShortageRequests: 'Запросы на найм',
        process: 'Обработать',
        comment: 'Комментарий',
    }
};

// ===================== UTILITY FUNCTIONS =====================
function t(key) {
    return translations[AppState.language][key] || key;
}

function formatDate(dateStr) {
    return dateStr;
}

function generateId(prefix) {
    return `${prefix}-${Date.now()}`;
}

// ===================== RENDER FUNCTIONS =====================
function render() {
    renderRoleNav();
    renderCurrentTime();
    renderMainContent();
    applyTheme();
    updateLanguageButtons();
}

function renderRoleNav() {
    const roles = [
        { id: 'store-manager', name: 'Store Manager', icon: '🏪' },
        { id: 'hq-admin', name: 'HQ Administrator', icon: '🏢' },
        { id: 'hr-specialist', name: 'HR Specialist', icon: '👥' },
        { id: 'client', name: 'Client', icon: '🛒' },
        { id: 'product-manager', name: 'Product Manager', icon: '📦' },
    ];
    
    const nav = document.getElementById('roleNav');
    nav.innerHTML = roles.map(role => `
        <button class="role-btn ${AppState.currentRole === role.id ? 'active' : ''}" data-role="${role.id}">
            <span class="role-icon">${role.icon}</span>
            <span class="role-name">${role.name}</span>
        </button>
    `).join('');
    
    // Add event listeners
    nav.querySelectorAll('.role-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            AppState.currentRole = btn.dataset.role;
            AppState.storeManagerPage = 1;
            AppState.hrSpecialistPage = 1;
            render();
        });
    });
}

function renderCurrentTime() {
    const timeEl = document.getElementById('currentTime');
    const locale = AppState.language === 'ru' ? 'ru-RU' : 'en-US';
    timeEl.textContent = new Date().toLocaleDateString(locale, { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
}

function renderMainContent() {
    const main = document.getElementById('mainContent');
    
    let content = '';
    switch(AppState.currentRole) {
        case 'store-manager':
            content = renderStoreManagerPage();
            break;
        case 'hq-admin':
            content = renderHQAdminPage();
            break;
        case 'hr-specialist':
            content = renderHRSpecialistPage();
            break;
        case 'client':
            content = renderClientPage();
            break;
        case 'product-manager':
            content = renderProductManagerPage();
            break;
    }
    
    main.innerHTML = `<div class="role-page active">${content}</div>`;
    
    // Attach event listeners after rendering
    attachEventListeners();
}

// ===================== STORE MANAGER PAGE =====================
function renderStoreManagerPage() {
    if (AppState.storeManagerPage === 1) {
        return renderStoreManagerDashboard();
    } else {
        return renderStoreManagerSecondPage();
    }
}

function renderStoreManagerDashboard() {
    const weeklyIncome = [12400, 15600, 13800, 16200, 14500, 17800, 15420];
    const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const maxIncome = Math.max(...weeklyIncome);
    
    const kpiData = [
        { title: t('dailyRevenue'), value: '$15,420', change: '+12%', positive: true },
        { title: t('customersToday'), value: '847', change: '+5%', positive: true },
        { title: t('avgTransaction'), value: '$48.50', change: '-2%', positive: false },
        { title: t('inventoryHealth'), value: '94%', change: '+3%', positive: true },
    ];
    
    const quickActions = [
        { icon: '📊', label: t('dailyReport') },
        { icon: '👥', label: t('staffOverview') },
        { icon: '📦', label: t('inventoryCheck') },
        { icon: '💰', label: t('cashRegister') },
    ];
    
    const storeNotifications = AppState.notifications.filter(n => 
        n.from === 'Product Manager' || n.from === 'HQ Admin' || n.from === 'HR Specialist'
    );
    
    return `
        <div class="store-manager-page">
            <div class="sm-top-section">
                <div class="sm-quick-actions">
                    <h3>${t('quickActions')}</h3>
                    <div class="quick-actions-grid">
                        ${quickActions.map(action => `
                            <button class="quick-action-btn">
                                <span class="action-icon">${action.icon}</span>
                                <span class="action-label">${action.label}</span>
                            </button>
                        `).join('')}
                    </div>
                    <button class="switch-page-btn" id="viewMetricsBtn">${t('viewStoreMetrics')}</button>
                </div>
                
                <div class="sm-income-chart">
                    <h3>${t('weeklyIncome')}</h3>
                    <div class="bar-chart">
                        ${weeklyIncome.map((income, i) => `
                            <div class="bar-group">
                                <div class="bar-value">$${(income / 1000).toFixed(1)}k</div>
                                <div class="bar" style="height: ${(income / maxIncome) * 200}px">
                                    <div class="bar-inner"></div>
                                </div>
                                <div class="bar-label">${weekDays[i]}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <div class="sm-kpi-section">
                ${kpiData.map(kpi => `
                    <div class="kpi-card">
                        <div class="kpi-title">${kpi.title}</div>
                        <div class="kpi-value">${kpi.value}</div>
                        <div class="kpi-change ${kpi.positive ? 'positive' : 'negative'}">
                            ${kpi.positive ? '↑' : '↓'} ${kpi.change}
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <div class="sm-bottom-section">
                <div class="sm-notifications">
                    <h3>${t('notifications')}</h3>
                    <div class="notifications-list">
                        ${storeNotifications.map(notif => `
                            <div class="notification-item ${notif.read ? 'read' : ''}">
                                <div class="notif-header">
                                    <span class="notif-from">${notif.from}</span>
                                    <span class="notif-date">${notif.date}</span>
                                </div>
                                <div class="notif-message">${notif.message}</div>
                                <span class="notif-type ${notif.type}">${notif.type}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderStoreManagerSecondPage() {
    return `
        <div class="store-manager-page">
            <div class="sm-second-page">
                <button class="back-btn" id="backToDashboard">${t('backDashboard')}</button>
                
                <div class="sm-metrics-section">
                    <h2>${t('storeMetrics')}</h2>
                    <div class="metrics-grid">
                        <div class="metric-card">
                            <h4>${t('totalRevenue')}</h4>
                            <div class="metric-value">$124,500</div>
                        </div>
                        <div class="metric-card">
                            <h4>${t('avgDailySales')}</h4>
                            <div class="metric-value">$4,150</div>
                        </div>
                        <div class="metric-card">
                            <h4>${t('customerSatisfaction')}</h4>
                            <div class="metric-value">4.6/5.0</div>
                        </div>
                        <div class="metric-card">
                            <h4>${t('returnRate')}</h4>
                            <div class="metric-value">2.3%</div>
                        </div>
                    </div>
                </div>
                
                <div class="sm-shifts-section">
                    <div class="shifts-header">
                        <h2>${t('employeeShifts')}</h2>
                        <div class="shifts-buttons">
                            <button class="shortage-btn" id="employeeShortageBtn">${t('employeeShortage')}</button>
                            <button class="add-shift-btn" id="addShiftBtn">${t('addShift')}</button>
                        </div>
                    </div>
                    ${renderShiftCalendar()}
                    <div class="shifts-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>${t('employee')}</th>
                                    <th>${t('date')}</th>
                                    <th>${t('time')}</th>
                                    <th>${t('position')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${AppState.shifts.map(shift => `
                                    <tr>
                                        <td>${shift.employeeName}</td>
                                        <td>${shift.date}</td>
                                        <td>${shift.time}</td>
                                        <td>${shift.position}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderShiftCalendar() {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return `
        <div class="shift-calendar">
            <div class="calendar-header">
                ${days.map(day => `<div class="calendar-day-header">${day}</div>`).join('')}
            </div>
            <div class="calendar-body">
                ${Array.from({ length: 7 }, (_, i) => {
                    const dayShifts = AppState.shifts.filter(s => {
                        const shiftDate = new Date(s.date);
                        return shiftDate.getDay() === (i + 1) % 7;
                    });
                    return `
                        <div class="calendar-day">
                            <div class="day-number">${i + 15}</div>
                            ${dayShifts.map(shift => `
                                <div class="shift-item">
                                    <span class="shift-employee">${shift.employeeName}</span>
                                    <span class="shift-time">${shift.time}</span>
                                </div>
                            `).join('')}
                        </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
}

// ===================== HQ ADMIN PAGE =====================
function renderHQAdminPage() {
    const selectedStore = AppState.selectedStore || AppState.stores[0];
    
    return `
        <div class="hq-admin-page">
            <div class="hq-top-section">
                <div class="hq-map-section">
                    <h3>${t('nearbyStores')}</h3>
                    <div class="store-map">
                        <div class="map-container">
                            ${AppState.stores.map((store, i) => `
                                <div class="map-marker ${selectedStore.id === store.id ? 'selected' : ''}" 
                                     data-store-id="${store.id}"
                                     style="left: ${20 + (i % 3) * 30}%; top: ${20 + Math.floor(i / 3) * 40}%;">
                                    <span class="marker-icon">📍</span>
                                    <span class="marker-name">${store.name}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
                
                <div class="hq-messages-section">
                    <h3>${t('messagesManagers')}</h3>
                    <div class="messages-list">
                        ${AppState.notifications.filter(n => n.from === 'Store Manager' || n.from === 'HR Specialist').map(notif => `
                            <div class="message-item">
                                <div class="message-header">
                                    <span class="message-from">${notif.from}</span>
                                    <span class="message-date">${notif.date}</span>
                                </div>
                                <div class="message-content">${notif.message}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <div class="hq-stores-section">
                    <div class="stores-header">
                        <h3>${t('storeOverview')}</h3>
                        <button class="compare-btn" id="compareStoresBtn">${t('compareStores')}</button>
                    </div>
                    <div class="stores-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>${t('storeName')}</th>
                                    <th>${t('todayIncome')}</th>
                                    <th>${t('rating')}</th>
                                    <th>${t('audit')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${AppState.stores.map(store => `
                                    <tr class="${selectedStore.id === store.id ? 'selected' : ''}" data-store-id="${store.id}">
                                        <td>${store.name}</td>
                                        <td>$${store.income.toLocaleString()}</td>
                                        <td>⭐ ${store.rating}</td>
                                        <td><span class="audit-badge ${store.auditStatus.toLowerCase()}">${t(store.auditStatus.toLowerCase())}</span></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                    <div class="store-details">
                        <h4>${selectedStore.name} Details</h4>
                        <div class="detail-row">
                            <span>${t('address')}:</span>
                            <span>${selectedStore.address}</span>
                        </div>
                        <div class="detail-row">
                            <span>${t('todayIncome')}:</span>
                            <span>$${selectedStore.income.toLocaleString()}</span>
                        </div>
                        <div class="detail-row">
                            <span>${t('rating')}:</span>
                            <span>⭐ ${selectedStore.rating}/5.0</span>
                        </div>
                        <div class="detail-row">
                            <span>${t('auditStatus')}:</span>
                            <span class="audit-badge ${selectedStore.auditStatus.toLowerCase()}">${t(selectedStore.auditStatus.toLowerCase())}</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="hq-requests-section">
                <div class="requests-header">
                    <h3>${t('incomingRequests')}</h3>
                    <button class="process-time-btn" id="processTimeBtn">${t('orderRequestComparison')}</button>
                </div>
                <div class="requests-list">
                    ${AppState.orderRequests.map(request => `
                        <div class="request-item ${request.status}">
                            <div class="request-info">
                                <span class="request-id">${request.id}</span>
                                <span class="request-store">${request.storeName}</span>
                                <span class="request-product">${request.productName}</span>
                                <span class="request-amount">×${request.amount}</span>
                                <span class="request-initial-date">${request.initialDate}</span>
                                ${request.processedDate ? `<span class="request-processed-date">→ ${request.processedDate}</span>` : ''}
                                <span class="request-status ${request.status}">${request.status}</span>
                            </div>
                            ${request.status === 'pending' ? `
                                <div class="request-actions">
                                    <input type="text" class="comment-input" placeholder="${t('addComment')}" data-request-id="${request.id}">
                                    <button class="deny-btn" data-request-id="${request.id}">${t('deny')}</button>
                                    <button class="approve-btn" data-request-id="${request.id}">${t('approve')}</button>
                                </div>
                            ` : ''}
                            ${request.comment ? `<div class="request-comment">${t('comment')}: ${request.comment}</div>` : ''}
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;
}

// ===================== HR SPECIALIST PAGE =====================
function renderHRSpecialistPage() {
    if (AppState.hrSpecialistPage === 1) {
        return renderHRSpecialistDashboard();
    } else {
        return renderHRSpecialistSecondPage();
    }
}

function renderHRSpecialistDashboard() {
    const hiredData = [5, 3, 4, 6, 2, 4];
    const firedData = [1, 2, 1, 3, 1, 2];
    const months = ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'];
    
    const employeeStats = {
        total: AppState.employees.length,
        testing: AppState.employees.filter(e => e.status === 'testing').length,
        fired: 2,
        vacation: AppState.employees.filter(e => e.status === 'vacation').length
    };
    
    const activeRequests = [
        { id: 'REQ-HR-001', employee: 'Alice Johnson', type: t('vacationRequest'), status: 'pending' },
        { id: 'REQ-HR-002', employee: 'Bob Williams', type: t('shiftChange'), status: 'approved' },
        { id: 'REQ-HR-003', employee: 'David Brown', type: t('sickLeave'), status: 'pending' },
        { id: 'REQ-HR-004', employee: 'Eva Martinez', type: t('trainingRequest'), status: 'pending' },
    ];
    
    const hrNotifications = AppState.notifications.filter(n => 
        n.from === 'Store Manager' || n.from === 'HQ Admin'
    );
    
    return `
        <div class="hr-specialist-page">
            <div class="hr-top-section">
                <div class="store-selector">
                    <label>${t('selectStore')}</label>
                    <select id="storeSelect">
                        ${AppState.stores.map(s => `
                            <option value="${s.name}">${s.name}</option>
                        `).join('')}
                    </select>
                </div>
                <div class="employee-graph">
                    <h3>${t('employeeChanges')}</h3>
                    <div class="line-chart">
                        <div class="chart-y-axis">
                            ${[6, 5, 4, 3, 2, 1, 0].map(n => `<span>${n}</span>`).join('')}
                        </div>
                        <div class="chart-area">
                            ${months.map((month, i) => `
                                <div class="chart-column">
                                    <div class="bar-group-hr">
                                        <div class="hired-bar" style="height: ${hiredData[i] * 25}px"></div>
                                        <div class="fired-bar" style="height: ${firedData[i] * 25}px"></div>
                                    </div>
                                    <span class="month-label">${month}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    <div class="chart-legend-hr">
                        <span class="legend-item"><span class="legend-color hired"></span> ${t('hired')}</span>
                        <span class="legend-item"><span class="legend-color fired"></span> ${t('fired')}</span>
                    </div>
                </div>
            </div>
            
            <div class="hr-stats-cards">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-info">
                        <span class="stat-value">${employeeStats.total}</span>
                        <span class="stat-label">${t('totalEmployees')}</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🔄</div>
                    <div class="stat-info">
                        <span class="stat-value">${employeeStats.testing}</span>
                        <span class="stat-label">${t('testingPeriod')}</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">❌</div>
                    <div class="stat-info">
                        <span class="stat-value">${employeeStats.fired}</span>
                        <span class="stat-label">${t('fired')}</span>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🏖️</div>
                    <div class="stat-info">
                        <span class="stat-value">${employeeStats.vacation}</span>
                        <span class="stat-label">${t('onVacation')}</span>
                    </div>
                </div>
            </div>
            
            ${AppState.employeeShortageRequests.length > 0 ? `
                <div class="hr-shortage-section">
                    <h3>${t('employeeShortageRequests')}</h3>
                    <div class="shortage-requests-list">
                        ${AppState.employeeShortageRequests.map(req => `
                            <div class="shortage-request-item ${req.status}">
                                <div class="shortage-info">
                                    <span class="shortage-id">${req.id}</span>
                                    <span class="shortage-store">${req.storeName}</span>
                                    <span class="shortage-role">${req.role}</span>
                                    <span class="shortage-amount">×${req.amount}</span>
                                    <span class="shortage-needed">by ${req.neededBy}</span>
                                    ${req.hasFiles ? '<span class="shortage-files">📎</span>' : ''}
                                    <span class="shortage-status ${req.status}">${req.status}</span>
                                </div>
                                ${req.status === 'pending' ? `
                                    <div class="shortage-actions">
                                        <input type="text" class="comment-input" placeholder="${t('addComment')}" data-shortage-id="${req.id}">
                                        <button class="deny-btn" data-shortage-id="${req.id}">${t('deny')}</button>
                                        <button class="approve-btn" data-shortage-id="${req.id}">${t('approve')}</button>
                                    </div>
                                ` : ''}
                                ${req.comment ? `<div class="request-comment">${t('comment')}: ${req.comment}</div>` : ''}
                            </div>
                        `).join('')}
                    </div>
                </div>
            ` : ''}
            
            <div class="hr-middle-section">
                <div class="hr-requests">
                    <h3>${t('activeRequests')}</h3>
                    <div class="requests-list-hr">
                        ${activeRequests.map(req => `
                            <div class="request-item-hr ${req.status}">
                                <div class="request-header-hr">
                                    <span class="request-id-hr">${req.id}</span>
                                    <span class="request-status-hr ${req.status}">${req.status}</span>
                                </div>
                                <div class="request-body-hr">
                                    <span class="employee-name">${req.employee}</span>
                                    <span class="request-type">${req.type}</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <div class="hr-second-page-btn">
                    <button id="hrSecondPageBtn">${t('approveCandidates')}</button>
                </div>
                
                <div class="hr-notifications">
                    <h3>${t('notifications')}</h3>
                    <div class="notifications-scroll">
                        ${hrNotifications.map(notif => `
                            <div class="notification-item-hr">
                                <div class="notif-header-hr">
                                    <span class="notif-from-hr">${notif.from}</span>
                                    <span class="notif-date-hr">${notif.date}</span>
                                </div>
                                <div class="notif-message-hr">${notif.message}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderHRSpecialistSecondPage() {
    const filteredIncidents = AppState.incidents.filter(i => 
        i.type === 'client-related' || i.type === 'employee'
    );
    
    return `
        <div class="hr-specialist-page">
            <div class="hr-second-page">
                <button class="back-btn" id="hrBackToDashboard">${t('backDashboard')}</button>
                
                <div class="hr-second-content">
                    <div class="incidents-section">
                        <h3>${t('complaintsIncidents')}</h3>
                        <div class="incidents-list">
                            ${filteredIncidents.map(incident => `
                                <div class="incident-item ${AppState.selectedIncident?.id === incident.id ? 'selected' : ''}" data-incident-id="${incident.id}">
                                    <div class="incident-header">
                                        <span class="incident-id">${incident.id}</span>
                                        <span class="incident-priority ${incident.priority}">${incident.priority}</span>
                                    </div>
                                    <div class="incident-client">${incident.clientName}</div>
                                    <div class="incident-desc">${incident.description}</div>
                                    <div class="incident-footer">
                                        <span class="incident-status">${incident.status}</span>
                                        <span class="incident-date">${incident.date}</span>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    
                    <div class="trainings-section">
                        <h3>${t('plannedTrainings')}</h3>
                        <table class="trainings-table">
                            <thead>
                                <tr>
                                    <th>${t('date')}</th>
                                    <th>${t('theme')}</th>
                                    <th>${t('participants')}</th>
                                    <th>${t('status')}</th>
                                    <th>${t('rating')}</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${AppState.trainings.map(t => `
                                    <tr>
                                        <td>${t.date}</td>
                                        <td>${t.theme}</td>
                                        <td>${t.participants}</td>
                                        <td><span class="status-badge ${t.status}">${t.status}</span></td>
                                        <td>${t.rating ? `⭐ ${t.rating}` : '-'}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
                
                ${AppState.selectedIncident ? `
                    <div class="incident-detail-panel">
                        <h4>${t('incidentDetails')} - ${AppState.selectedIncident.id}</h4>
                        <div class="detail-section">
                            <h5>${t('historyChanges')}</h5>
                            <div class="history-list">
                                ${AppState.selectedIncident.history.map(h => `
                                    <div class="history-item">
                                        <span class="history-date">${h.date}</span>
                                        <span class="history-action">${h.action}</span>
                                        <span class="history-by">by ${h.by}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                        <div class="detail-section">
                            <h5>${t('detailedDescription')}</h5>
                            <p>${AppState.selectedIncident.detailedDescription}</p>
                        </div>
                        <div class="detail-section">
                            <h5>${t('assignEmployee')}</h5>
                            <select id="assignEmployeeSelect">
                                <option value="">${t('selectEmployee')}</option>
                                ${AppState.employees.filter(e => e.status === 'active').map(e => `
                                    <option value="${e.name}">${e.name} - ${e.position}</option>
                                `).join('')}
                            </select>
                        </div>
                        <div class="incident-actions">
                            <button class="close-incident-btn" id="closeIncidentBtn">${t('closeIncident')}</button>
                            <button class="assign-btn" id="assignIncidentBtn">${t('assign')}</button>
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

// ===================== CLIENT PAGE =====================
function renderClientPage() {
    const banners = [
        { id: 1, title: 'Fresh Organic Products', subtitle: 'Up to 30% off', color: '#4CAF50' },
        { id: 2, title: 'Weekend Special', subtitle: 'Buy 2 Get 1 Free', color: '#2196F3' },
        { id: 3, title: 'New Arrivals', subtitle: 'Premium Selection', color: '#9C27B0' },
    ];
    
    const quickLinks = [
        { icon: '🛒', label: t('cart'), count: 3 },
        { icon: '📜', label: t('orderHistory') },
        { icon: '❤️', label: t('favorites') },
        { icon: '🏷️', label: t('coupons') },
        { icon: '⚙️', label: t('settings') },
    ];
    
    const recommendations = [
        { id: 1, name: 'Organic Green Tea', price: 12.99, desc: 'Premium Japanese green tea leaves', image: '🍵' },
        { id: 2, name: 'Manuka Honey', price: 24.99, desc: 'Raw organic honey from New Zealand', image: '🍯' },
        { id: 3, name: 'Almond Butter', price: 9.99, desc: 'Creamy roasted almond spread', image: '🥜' },
        { id: 4, name: 'Coconut Water', price: 3.49, desc: 'Natural hydration from young coconuts', image: '🥥' },
    ];
    
    const orderNotifications = [
        { id: 1, message: 'Order ORD-001 is on its way!', time: '2 hours ago' },
        { id: 2, message: 'Order ORD-002 has been delivered', time: '1 day ago' },
        { id: 3, message: 'Your refund for ORD-005 has been processed', time: '3 days ago' },
    ];
    
    return `
        <div class="client-page">
            <div class="client-top-section">
                <div class="search-section">
                    <input type="text" class="search-bar" placeholder="${t('searchProducts')}" id="searchInput">
                </div>
                <div class="bonus-balance">
                    <span class="bonus-icon">🎁</span>
                    <div class="bonus-info">
                        <span class="bonus-label">${t('bonusBalance')}</span>
                        <span class="bonus-value">${AppState.bonusBalance} ${t('pts')}</span>
                    </div>
                </div>
            </div>
            
            <div class="banners-section">
                ${banners.map(banner => `
                    <div class="banner" style="background: linear-gradient(135deg, ${banner.color}, ${banner.color}dd)">
                        <div class="banner-content">
                            <h3>${banner.title}</h3>
                            <p>${banner.subtitle}</p>
                        </div>
                    </div>
                `).join('')}
            </div>
            
            <div class="client-middle-section">
                <div class="quick-links-section">
                    <h3>${t('quickLinks')}</h3>
                    <div class="quick-links-grid">
                        ${quickLinks.map((link, i) => `
                            <button class="quick-link-btn">
                                <span class="link-icon">${link.icon}</span>
                                <span class="link-label">${link.label}</span>
                                ${link.count ? `<span class="link-count">${link.count}</span>` : ''}
                            </button>
                        `).join('')}
                    </div>
                </div>
                
                <div class="recommendations-section">
                    <h3>${t('recommended')}</h3>
                    <div class="recommendations-grid">
                        ${recommendations.map(rec => `
                            <div class="recommendation-card">
                                <div class="rec-image">${rec.image}</div>
                                <div class="rec-info">
                                    <h4>${rec.name}</h4>
                                    <p>${rec.desc}</p>
                                    <div class="rec-footer">
                                        <span class="rec-price">$${rec.price.toFixed(2)}</span>
                                        <button class="add-to-cart-btn" data-product-name="${rec.name}">${t('addToCart')}</button>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
            
            <div class="notifications-scroll-section">
                <h3>${t('orderUpdates')}</h3>
                <div class="order-notifications">
                    ${orderNotifications.map(notif => `
                        <div class="order-notif-item">
                            <span class="notif-message">${notif.message}</span>
                            <span class="notif-time">${notif.time}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="orders-section">
                <div class="orders-table-section">
                    <h3>${t('myOrders')}</h3>
                    <table class="orders-table">
                        <thead>
                            <tr>
                                <th>${t('orderId')}</th>
                                <th>${t('date')}</th>
                                <th>${t('price')}</th>
                                <th>${t('status')}</th>
                                <th>${t('actions')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${AppState.orders.map(order => `
                                <tr class="${AppState.selectedOrder?.id === order.id ? 'selected' : ''}" data-order-id="${order.id}">
                                    <td>${order.id}</td>
                                    <td>${order.date}</td>
                                    <td>$${order.price.toFixed(2)}</td>
                                    <td><span class="status-badge order-status ${order.status.replace(' ', '-')}">${t(order.status.replace(' ', ''))}</span></td>
                                    <td>
                                        <div class="order-actions">
                                            ${order.status === 'on the way' ? `<button data-action="cancel" data-order-id="${order.id}">${t('cancel')}</button>` : ''}
                                            ${order.status === 'delivered' ? `<button data-action="reorder" data-order-id="${order.id}">${t('reorder')}</button>` : ''}
                                        </div>
                                    </td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <button class="new-order-btn" id="newOrderBtn">${t('createNewOrder')}</button>
                </div>
                
                <div class="order-details-section">
                    <h3>${t('orderDetails')}</h3>
                    ${AppState.selectedOrder ? `
                        <div class="selected-order-details">
                            <div class="detail-row">
                                <span>${t('orderId')}:</span>
                                <span>${AppState.selectedOrder.id}</span>
                            </div>
                            <div class="detail-row">
                                <span>${t('status')}:</span>
                                <span class="status-badge ${AppState.selectedOrder.status}">${t(AppState.selectedOrder.status.replace(' ', ''))}</span>
                            </div>
                            <div class="detail-row">
                                <span>${t('estimatedArrival')}:</span>
                                <span>${AppState.selectedOrder.status === 'delivered' ? t('delivered') : '2-3 business days'}</span>
                            </div>
                            <div class="order-items">
                                <h4>${t('items')}:</h4>
                                ${AppState.selectedOrder.items.map(item => `
                                    <div class="order-item">
                                        <span>${item.name} × ${item.quantity}</span>
                                        <span>$${(item.price * item.quantity).toFixed(2)}</span>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    ` : `
                        <div class="no-order-selected">
                            <p>${t('selectOrder')}</p>
                        </div>
                    `}
                </div>
            </div>
        </div>
    `;
}

// ===================== PRODUCT MANAGER PAGE =====================
function renderProductManagerPage() {
    const lowStockProducts = AppState.products.filter(p => p.amount < 5);
    const allTasksDone = AppState.tasks.every(t => t.completed);
    const monthlyIncidents = AppState.incidents.filter(i => {
        const incidentDate = new Date(i.date);
        const now = new Date();
        return incidentDate.getMonth() === now.getMonth() && incidentDate.getFullYear() === now.getFullYear();
    });
    
    return `
        <div class="product-manager-page">
            <div class="pm-top-section">
                <div class="todo-section">
                    <h3>${t('todoList')}</h3>
                    <div class="todo-list">
                        ${AppState.tasks.map(task => `
                            <div class="todo-item ${task.completed ? 'completed' : ''}">
                                <label class="todo-checkbox">
                                    <input type="checkbox" ${task.completed ? 'checked' : ''} data-task-id="${task.id}">
                                </label>
                                <span class="todo-text">${task.text}</span>
                                ${task.completed && task.completedDate ? `<span class="completed-date">${task.completedDate}</span>` : ''}
                                ${!task.isMandatory ? `<button class="remove-task-btn" data-task-id="${task.id}">×</button>` : ''}
                                ${task.isMandatory ? `<span class="mandatory-badge">${t('required')}</span>` : ''}
                            </div>
                        `).join('')}
                    </div>
                    <div class="add-task-section">
                        <input type="text" placeholder="${t('addTaskPlaceholder')}" id="newTaskInput">
                        <button id="addTaskBtn">${t('addTask')}</button>
                    </div>
                </div>
                
                <div class="pm-actions-section">
                    <button class="send-report-btn ${allTasksDone ? 'active' : 'disabled'}" id="sendReportBtn" ${!allTasksDone ? 'disabled' : ''}>
                        ${t('sendReport')}
                    </button>
                    ${AppState.reportSent ? `<div class="report-sent-msg">${t('reportSent')}</div>` : ''}
                    <button class="order-products-btn" id="orderProductsBtn">${t('orderProducts')}</button>
                </div>
            </div>
            
            <div class="pm-middle-section">
                <div class="low-stock-section">
                    <h3>${t('lowStock')}</h3>
                    <div class="low-stock-list">
                        ${lowStockProducts.map(product => `
                            <div class="low-stock-item">
                                <div class="product-info">
                                    <span class="product-name">${product.name}</span>
                                    <span class="product-category">${product.category}</span>
                                </div>
                                <div class="stock-info">
                                    <span class="stock-count ${product.amount <= 2 ? 'critical' : 'warning'}">${product.amount} ${t('left')}</span>
                                    <span class="product-price">$${product.price.toFixed(2)}</span>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                <div class="incident-form-section">
                    <h3>${t('registerIncident')}</h3>
                    <div class="incident-form">
                        <div class="form-row">
                            <label>${t('incidentType')}</label>
                            <select id="incidentType">
                                <option value="technical">${t('technical')}</option>
                                <option value="product">${t('product')}</option>
                                <option value="employee">${t('employee')}</option>
                                <option value="client-related">${t('clientRelated')}</option>
                            </select>
                        </div>
                        <div class="form-row">
                            <label>${t('clientNameSurname')}</label>
                            <input type="text" id="incidentClientName" placeholder="${t('enterClientName')}">
                        </div>
                        <div class="form-row">
                            <label>${t('shortDescription')}</label>
                            <input type="text" id="incidentShortDesc" placeholder="${t('briefDescription')}">
                        </div>
                        <div class="form-row">
                            <label>${t('detailedDescription')}</label>
                            <textarea id="incidentDetailedDesc" placeholder="${t('fullDetails')}"></textarea>
                        </div>
                        <div class="form-row">
                            <button class="attach-btn" id="attachFilesBtn">${t('attachFiles')}</button>
                        </div>
                        <button class="register-incident-btn" id="registerIncidentBtn">${t('registerIncidentBtn')}</button>
                    </div>
                </div>
            </div>
            
            <div class="pm-bottom-section">
                <div class="incident-history-section">
                    <h3>${t('incidentHistory')}</h3>
                    <div class="incident-history-list">
                        ${monthlyIncidents.map(incident => `
                            <div class="incident-history-item" data-incident-hover="${incident.id}">
                                <span class="incident-id">${incident.id}</span>
                                <span class="incident-desc">${incident.description}</span>
                                <span class="incident-date">${incident.date}</span>
                                <span class="incident-status ${incident.status}">${incident.status === 'open' ? t('open') : incident.status === 'resolved' ? t('resolved') : t('inProgress')}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
                
                ${AppState.hoveredIncident ? `
                    <div class="incident-details-popup">
                        <h4>${t('incidentDetails')}</h4>
                        <div class="detail-row">
                            <span>ID:</span>
                            <span>${AppState.hoveredIncident.id}</span>
                        </div>
                        <div class="detail-row">
                            <span>${t('incidentType')}:</span>
                            <span>${AppState.hoveredIncident.type}</span>
                        </div>
                        <div class="detail-row">
                            <span>${t('status')}:</span>
                            <span>${AppState.hoveredIncident.status}</span>
                        </div>
                        <div class="detail-row">
                            <span>${t('priority')}:</span>
                            <span>${AppState.hoveredIncident.priority}</span>
                        </div>
                        <div class="detail-section">
                            <span>${t('detailedDescription')}:</span>
                            <p>${AppState.hoveredIncident.detailedDescription}</p>
                        </div>
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

// ===================== MODAL FUNCTIONS =====================
function showModal(content) {
    const container = document.getElementById('modalContainer');
    container.innerHTML = `
        <div class="modal-overlay" id="modalOverlay">
            <div class="modal-content" onclick="event.stopPropagation()">
                ${content}
            </div>
        </div>
    `;
    
    container.querySelector('#modalOverlay').addEventListener('click', () => {
        container.innerHTML = '';
    });
}

function closeModal() {
    document.getElementById('modalContainer').innerHTML = '';
}

function showCompareStoresModal() {
    const storeWeeklyIncome = AppState.stores.map(s => ({
        name: s.name,
        income: [
            12000 + Math.random() * 5000, 
            13000 + Math.random() * 4000, 
            11000 + Math.random() * 6000, 
            14000 + Math.random() * 3000, 
            12000 + Math.random() * 5000, 
            15000 + Math.random() * 4000, 
            s.income
        ]
    }));
    
    const content = `
        <h3>${t('storeComparison')}</h3>
        <div class="compare-chart">
            <div class="grouped-bar-chart">
                ${storeWeeklyIncome.map(store => `
                    <div class="store-bars">
                        <div class="store-name-label">${store.name.split(' ')[0]}</div>
                        <div class="week-bars">
                            ${store.income.map(inc => `
                                <div class="mini-bar" style="height: ${(inc / 20000) * 100}px" title="$${Math.round(inc).toLocaleString()}"></div>
                            `).join('')}
                        </div>
                    </div>
                `).join('')}
            </div>
            <div class="chart-legend">
                <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
            </div>
        </div>
        <button class="close-modal-btn" onclick="closeModal()">${t('close')}</button>
    `;
    
    showModal(content);
}

function showProcessTimeModal() {
    const getStoreProcessTime = (storeName) => {
        const storeRequests = AppState.orderRequests.filter(r => 
            r.storeName === storeName && r.processedDate && r.initialDate
        );
        if (storeRequests.length === 0) return 0;
        const totalDays = storeRequests.reduce((sum, r) => {
            const initial = new Date(r.initialDate);
            const processed = new Date(r.processedDate);
            return sum + Math.ceil((processed.getTime() - initial.getTime()) / (1000 * 60 * 60 * 24));
        }, 0);
        return Math.round(totalDays / storeRequests.length * 10) / 10;
    };
    
    const content = `
        <h3>${t('processTimeComparison')}</h3>
        <div class="process-time-chart">
            ${AppState.stores.map(store => {
                const avgTime = getStoreProcessTime(store.name);
                return `
                    <div class="process-time-item">
                        <div class="process-store-name">${store.name}</div>
                        <div class="process-bar-container">
                            <div class="process-bar" style="width: ${Math.min(avgTime * 10, 100)}%"></div>
                        </div>
                        <div class="process-time-value">${avgTime} ${t('days')}</div>
                    </div>
                `;
            }).join('')}
        </div>
        <button class="close-modal-btn" onclick="closeModal()">${t('close')}</button>
    `;
    
    showModal(content);
}

function showAddShiftModal() {
    const content = `
        <h3>${t('addNewShift')}</h3>
        <div class="form-group">
            <label>${t('employeeName')}</label>
            <input type="text" id="shiftEmployeeName" placeholder="${t('employeeName')}">
        </div>
        <div class="form-group">
            <label>${t('date')}</label>
            <input type="date" id="shiftDate">
        </div>
        <div class="form-group">
            <label>${t('time')}</label>
            <input type="text" id="shiftTime" placeholder="e.g., 08:00 - 16:00">
        </div>
        <div class="form-group">
            <label>${t('position')}</label>
            <input type="text" id="shiftPosition" placeholder="${t('position')}">
        </div>
        <div class="modal-actions">
            <button class="cancel-btn" onclick="closeModal()">${t('cancel')}</button>
            <button class="confirm-btn" id="confirmAddShift">${t('confirm')}</button>
        </div>
    `;
    
    showModal(content);
    
    document.getElementById('confirmAddShift').addEventListener('click', () => {
        const employeeName = document.getElementById('shiftEmployeeName').value;
        const date = document.getElementById('shiftDate').value;
        const time = document.getElementById('shiftTime').value;
        const position = document.getElementById('shiftPosition').value;
        
        if (employeeName && date && time && position) {
            AppState.shifts.push({
                id: `SH-${String(AppState.shifts.length + 1).padStart(3, '0')}`,
                employeeName, date, time, position
            });
            closeModal();
            render();
        }
    });
}

function showEmployeeShortageModal() {
    const content = `
        <h3>${t('recruitmentRequest')}</h3>
        <div class="form-group">
            <label>${t('employeeRole')}</label>
            <input type="text" id="shortageRole" placeholder="${t('enterRole')}">
        </div>
        <div class="form-group">
            <label>${t('workersNeeded')}</label>
            <input type="number" id="shortageAmount" min="1" value="1">
        </div>
        <div class="form-group">
            <label>${t('neededBy')}</label>
            <input type="date" id="shortageNeededBy">
        </div>
        <div class="form-group">
            <button class="attach-btn" id="shortageAttachFiles">${t('attachFiles')}</button>
        </div>
        <div class="modal-actions">
            <button class="cancel-btn" onclick="closeModal()">${t('cancel')}</button>
            <button class="confirm-btn" id="confirmShortage">${t('sendRequest')}</button>
        </div>
    `;
    
    showModal(content);
    
    let hasFiles = false;
    document.getElementById('shortageAttachFiles').addEventListener('click', () => {
        hasFiles = !hasFiles;
        document.getElementById('shortageAttachFiles').textContent = `${t('attachFiles')} ${hasFiles ? '✓' : ''}`;
    });
    
    document.getElementById('confirmShortage').addEventListener('click', () => {
        const role = document.getElementById('shortageRole').value;
        const amount = parseInt(document.getElementById('shortageAmount').value) || 1;
        const neededBy = document.getElementById('shortageNeededBy').value;
        
        if (role && neededBy) {
            AppState.employeeShortageRequests.push({
                id: `ESR-${String(AppState.employeeShortageRequests.length + 1).padStart(3, '0')}`,
                storeName: 'Downtown Store',
                role,
                amount,
                neededBy,
                hasFiles,
                status: 'pending',
                date: new Date().toISOString().split('T')[0]
            });
            closeModal();
            render();
        }
    });
}

function showOrderProductsModal() {
    const content = `
        <h3>${t('orderProducts')}</h3>
        <div class="form-group">
            <label>${t('product')}</label>
            <select id="orderProductSelect">
                <option value="">${t('selectProduct')}</option>
                ${AppState.products.map(p => `
                    <option value="${p.name}">${p.name} - $${p.price.toFixed(2)}</option>
                `).join('')}
            </select>
        </div>
        <div class="form-group">
            <label>${t('amount')}</label>
            <input type="number" id="orderProductAmount" min="1" value="1">
        </div>
        <div class="modal-actions">
            <button class="cancel-btn" onclick="closeModal()">${t('cancel')}</button>
            <button class="confirm-btn" id="confirmOrderProduct">${t('sendRequest')}</button>
        </div>
    `;
    
    showModal(content);
    
    document.getElementById('confirmOrderProduct').addEventListener('click', () => {
        const productName = document.getElementById('orderProductSelect').value;
        const amount = parseInt(document.getElementById('orderProductAmount').value) || 1;
        
        if (productName) {
            AppState.orderRequests.unshift({
                id: `REQ-${Date.now()}`,
                storeName: 'Downtown Store',
                productName,
                amount,
                status: 'pending',
                initialDate: new Date().toISOString().split('T')[0]
            });
            closeModal();
            render();
        }
    });
}

function showNewOrderModal() {
    const cartTotal = AppState.cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const finalTotal = AppState.useBonuses ? Math.max(0, cartTotal - AppState.bonusBalance * 0.01) : cartTotal;
    
    const content = `
        <h3>${t('createNewOrder')}</h3>
        <div class="order-modal">
            <div class="product-catalog">
                <h4>${t('availableProducts')}</h4>
                <div class="catalog-grid">
                    ${AppState.products.map(product => `
                        <div class="catalog-item">
                            <div class="catalog-item-info">
                                <span class="catalog-item-name">${product.name}</span>
                                <span class="catalog-item-category">${product.category}</span>
                                <span class="catalog-item-price">$${product.price.toFixed(2)}</span>
                            </div>
                            <button class="add-to-cart-btn" data-product-id="${product.id}">${t('addToCart')}</button>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="cart-summary">
                <h4>${t('yourCart')}</h4>
                ${AppState.cart.length > 0 ? `
                    ${AppState.cart.map((item, i) => `
                        <div class="cart-item">
                            <span>${item.product.name} × ${item.quantity}</span>
                            <span>$${(item.product.price * item.quantity).toFixed(2)}</span>
                        </div>
                    `).join('')}
                    <div class="bonus-toggle">
                        <label>
                            <input type="checkbox" id="useBonusesCheckbox" ${AppState.useBonuses ? 'checked' : ''}>
                            ${t('useBonus')} ${AppState.bonusBalance} ${t('bonusPoints')} ($${(AppState.bonusBalance * 0.01).toFixed(2)} value)
                        </label>
                    </div>
                    <div class="cart-total">
                        <span>${t('total')}</span>
                        <span id="cartTotalDisplay">$${finalTotal.toFixed(2)}</span>
                    </div>
                    <div class="payment-section">
                        <h5>${t('paymentInfo')}</h5>
                        <div class="fake-card">
                            <div class="card-number">•••• •••• •••• 4242</div>
                            <div class="card-details">
                                <span>EXP: 12/26</span>
                                <span>CVV: •••</span>
                            </div>
                        </div>
                    </div>
                    <button class="place-order-btn" id="placeOrderBtn">${t('placeOrder')}</button>
                ` : `
                    <p class="empty-cart">${t('emptyCart')}</p>
                `}
            </div>
        </div>
        <button class="close-modal-btn" onclick="closeModal()">${t('close')}</button>
    `;
    
    showModal(content);
    
    // Add event listeners for cart functionality
    document.querySelectorAll('[data-product-id]').forEach(btn => {
        btn.addEventListener('click', () => {
            const productId = btn.dataset.productId;
            const product = AppState.products.find(p => p.id === productId);
            if (product) {
                const existing = AppState.cart.find(c => c.product.id === productId);
                if (existing) {
                    existing.quantity++;
                } else {
                    AppState.cart.push({ product, quantity: 1 });
                }
                showNewOrderModal(); // Refresh modal
            }
        });
    });
    
    const useBonusesCheckbox = document.getElementById('useBonusesCheckbox');
    if (useBonusesCheckbox) {
        useBonusesCheckbox.addEventListener('change', (e) => {
            AppState.useBonuses = e.target.checked;
            showNewOrderModal(); // Refresh modal
        });
    }
    
    const placeOrderBtn = document.getElementById('placeOrderBtn');
    if (placeOrderBtn) {
        placeOrderBtn.addEventListener('click', () => {
            if (AppState.cart.length > 0) {
                const cartTotal = AppState.cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
                const finalTotal = AppState.useBonuses ? Math.max(0, cartTotal - AppState.bonusBalance * 0.01) : cartTotal;
                
                AppState.orders.unshift({
                    id: `ORD-${String(AppState.orders.length + 1).padStart(3, '0')}`,
                    date: new Date().toISOString().split('T')[0],
                    price: finalTotal,
                    status: 'on the way',
                    items: AppState.cart.map(c => ({ name: c.product.name, quantity: c.quantity, price: c.product.price }))
                });
                AppState.cart = [];
                AppState.useBonuses = false;
                closeModal();
                render();
            }
        });
    }
}

// ===================== EVENT HANDLERS =====================
function attachEventListeners() {
    // Theme buttons
    document.querySelectorAll('.theme-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            AppState.theme = btn.dataset.theme;
            document.body.className = `theme-${AppState.theme}`;
            document.querySelectorAll('.theme-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            render();
        });
    });
    
    // Language buttons
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            AppState.language = btn.dataset.lang;
            document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            render();
        });
    });
    
    // Store Manager page
    const viewMetricsBtn = document.getElementById('viewMetricsBtn');
    if (viewMetricsBtn) {
        viewMetricsBtn.addEventListener('click', () => {
            AppState.storeManagerPage = 2;
            render();
        });
    }
    
    const backToDashboard = document.getElementById('backToDashboard');
    if (backToDashboard) {
        backToDashboard.addEventListener('click', () => {
            AppState.storeManagerPage = 1;
            render();
        });
    }
    
    const addShiftBtn = document.getElementById('addShiftBtn');
    if (addShiftBtn) {
        addShiftBtn.addEventListener('click', showAddShiftModal);
    }
    
    const employeeShortageBtn = document.getElementById('employeeShortageBtn');
    if (employeeShortageBtn) {
        employeeShortageBtn.addEventListener('click', showEmployeeShortageModal);
    }
    
    // HQ Admin page
    document.querySelectorAll('[data-store-id]').forEach(el => {
        el.addEventListener('click', () => {
            const storeId = el.dataset.storeId;
            AppState.selectedStore = AppState.stores.find(s => s.id === storeId);
            render();
        });
    });
    
    const compareStoresBtn = document.getElementById('compareStoresBtn');
    if (compareStoresBtn) {
        compareStoresBtn.addEventListener('click', showCompareStoresModal);
    }
    
    const processTimeBtn = document.getElementById('processTimeBtn');
    if (processTimeBtn) {
        processTimeBtn.addEventListener('click', showProcessTimeModal);
    }
    
    // Request actions
    document.querySelectorAll('[data-request-id]').forEach(btn => {
        if (btn.classList.contains('approve-btn') || btn.classList.contains('deny-btn')) {
            btn.addEventListener('click', () => {
                const requestId = btn.dataset.requestId;
                const approve = btn.classList.contains('approve-btn');
                const commentInput = document.querySelector(`input[data-request-id="${requestId}"]`);
                const comment = commentInput ? commentInput.value : '';
                
                AppState.orderRequests = AppState.orderRequests.map(r => {
                    if (r.id === requestId) {
                        return {
                            ...r,
                            status: approve ? 'approved' : 'denied',
                            comment,
                            processedDate: new Date().toISOString().split('T')[0]
                        };
                    }
                    return r;
                });
                render();
            });
        }
    });
    
    // Shortage request actions
    document.querySelectorAll('[data-shortage-id]').forEach(btn => {
        if (btn.classList.contains('approve-btn') || btn.classList.contains('deny-btn')) {
            btn.addEventListener('click', () => {
                const shortageId = btn.dataset.shortageId;
                const approve = btn.classList.contains('approve-btn');
                const commentInput = document.querySelector(`input[data-shortage-id="${shortageId}"]`);
                const comment = commentInput ? commentInput.value : '';
                
                AppState.employeeShortageRequests = AppState.employeeShortageRequests.map(r => {
                    if (r.id === shortageId) {
                        // Send notification to Store Manager
                        AppState.notifications.unshift({
                            id: `N-${Date.now()}`,
                            from: 'HR Specialist',
                            message: `Employee shortage request ${approve ? 'approved' : 'denied'}: ${r.amount}x ${r.role}. ${comment}`,
                            type: approve ? 'success' : 'warning',
                            date: new Date().toISOString().split('T')[0],
                            read: false
                        });
                        return { ...r, status: approve ? 'approved' : 'denied', comment };
                    }
                    return r;
                });
                render();
            });
        }
    });
    
    // HR Specialist page
    const hrSecondPageBtn = document.getElementById('hrSecondPageBtn');
    if (hrSecondPageBtn) {
        hrSecondPageBtn.addEventListener('click', () => {
            AppState.hrSpecialistPage = 2;
            render();
        });
    }
    
    const hrBackToDashboard = document.getElementById('hrBackToDashboard');
    if (hrBackToDashboard) {
        hrBackToDashboard.addEventListener('click', () => {
            AppState.hrSpecialistPage = 1;
            AppState.selectedIncident = null;
            render();
        });
    }
    
    // Incident selection
    document.querySelectorAll('[data-incident-id]').forEach(el => {
        el.addEventListener('click', () => {
            const incidentId = el.dataset.incidentId;
            AppState.selectedIncident = AppState.incidents.find(i => i.id === incidentId);
            render();
        });
    });
    
    const closeIncidentBtn = document.getElementById('closeIncidentBtn');
    if (closeIncidentBtn) {
        closeIncidentBtn.addEventListener('click', () => {
            if (AppState.selectedIncident) {
                AppState.incidents = AppState.incidents.map(i => {
                    if (i.id === AppState.selectedIncident.id) {
                        return {
                            ...i,
                            status: 'resolved',
                            history: [...i.history, { date: new Date().toISOString().split('T')[0], action: 'Incident closed', by: 'HR Specialist' }]
                        };
                    }
                    return i;
                });
                AppState.selectedIncident = null;
                render();
            }
        });
    }
    
    const assignIncidentBtn = document.getElementById('assignIncidentBtn');
    if (assignIncidentBtn) {
        assignIncidentBtn.addEventListener('click', () => {
            const select = document.getElementById('assignEmployeeSelect');
            if (select && select.value && AppState.selectedIncident) {
                AppState.incidents = AppState.incidents.map(i => {
                    if (i.id === AppState.selectedIncident.id) {
                        return {
                            ...i,
                            assignedTo: select.value,
                            status: 'in progress',
                            history: [...i.history, { date: new Date().toISOString().split('T')[0], action: `Assigned to ${select.value}`, by: 'HR Specialist' }]
                        };
                    }
                    return i;
                });
                AppState.selectedIncident = null;
                render();
            }
        });
    }
    
    // Client page
    document.querySelectorAll('[data-order-id]').forEach(el => {
        if (!el.dataset.action) {
            el.addEventListener('click', () => {
                const orderId = el.dataset.orderId;
                AppState.selectedOrder = AppState.orders.find(o => o.id === orderId);
                render();
            });
        }
    });
    
    document.querySelectorAll('[data-action]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const action = btn.dataset.action;
            const orderId = btn.dataset.orderId;
            
            if (action === 'cancel') {
                AppState.orders = AppState.orders.map(o => 
                    o.id === orderId ? { ...o, status: 'cancelled' } : o
                );
            } else if (action === 'reorder') {
                const order = AppState.orders.find(o => o.id === orderId);
                if (order) {
                    AppState.orders.unshift({
                        id: `ORD-${String(AppState.orders.length + 1).padStart(3, '0')}`,
                        date: new Date().toISOString().split('T')[0],
                        price: order.price,
                        status: 'on the way',
                        items: [...order.items]
                    });
                }
            }
            render();
        });
    });
    
    const newOrderBtn = document.getElementById('newOrderBtn');
    if (newOrderBtn) {
        newOrderBtn.addEventListener('click', showNewOrderModal);
    }
    
    // Product Manager page
    document.querySelectorAll('[data-task-id]').forEach(el => {
        if (el.type === 'checkbox') {
            el.addEventListener('change', () => {
                const taskId = el.dataset.taskId;
                AppState.tasks = AppState.tasks.map(t => {
                    if (t.id === taskId) {
                        return {
                            ...t,
                            completed: !t.completed,
                            completedDate: !t.completed ? new Date().toISOString().split('T')[0] : undefined
                        };
                    }
                    return t;
                });
                render();
            });
        } else if (el.classList.contains('remove-task-btn')) {
            el.addEventListener('click', () => {
                const taskId = el.dataset.taskId;
                const task = AppState.tasks.find(t => t.id === taskId);
                if (task && !task.isMandatory) {
                    AppState.tasks = AppState.tasks.filter(t => t.id !== taskId);
                    render();
                }
            });
        }
    });
    
    const addTaskBtn = document.getElementById('addTaskBtn');
    if (addTaskBtn) {
        addTaskBtn.addEventListener('click', () => {
            const input = document.getElementById('newTaskInput');
            if (input && input.value.trim()) {
                AppState.tasks.push({
                    id: `T-${String(AppState.tasks.length + 1).padStart(3, '0')}`,
                    text: input.value.trim(),
                    completed: false,
                    isMandatory: false
                });
                render();
            }
        });
    }
    
    const sendReportBtn = document.getElementById('sendReportBtn');
    if (sendReportBtn) {
        sendReportBtn.addEventListener('click', () => {
            const allTasksDone = AppState.tasks.every(t => t.completed);
            if (allTasksDone) {
                const lowStockCount = AppState.products.filter(p => p.amount < 5).length;
                AppState.notifications.unshift({
                    id: `N-${Date.now()}`,
                    from: 'Product Manager',
                    message: `Daily Report: ${AppState.tasks.filter(t => t.completed).length} tasks completed, ${lowStockCount} products need restocking`,
                    type: 'info',
                    date: new Date().toISOString().split('T')[0],
                    read: false
                });
                AppState.reportSent = true;
                render();
                setTimeout(() => {
                    AppState.reportSent = false;
                    render();
                }, 3000);
            }
        });
    }
    
    const orderProductsBtn = document.getElementById('orderProductsBtn');
    if (orderProductsBtn) {
        orderProductsBtn.addEventListener('click', showOrderProductsModal);
    }
    
    const registerIncidentBtn = document.getElementById('registerIncidentBtn');
    if (registerIncidentBtn) {
        registerIncidentBtn.addEventListener('click', () => {
            const type = document.getElementById('incidentType').value;
            const clientName = document.getElementById('incidentClientName').value || 'N/A';
            const description = document.getElementById('incidentShortDesc').value;
            const detailedDescription = document.getElementById('incidentDetailedDesc').value;
            
            if (description) {
                AppState.incidents.unshift({
                    id: `INC-${String(AppState.incidents.length + 1).padStart(3, '0')}`,
                    type,
                    clientName,
                    description,
                    detailedDescription,
                    status: 'open',
                    priority: 'medium',
                    date: new Date().toISOString().split('T')[0],
                    history: [{ date: new Date().toISOString().split('T')[0], action: 'Incident registered', by: 'Product Manager' }]
                });
                
                // Send notification
                AppState.notifications.unshift({
                    id: `N-${Date.now()}`,
                    from: 'Product Manager',
                    message: `New ${type} incident: ${description}`,
                    type: 'warning',
                    date: new Date().toISOString().split('T')[0],
                    read: false
                });
                
                render();
            }
        });
    }
    
    // Incident hover for Product Manager
    document.querySelectorAll('[data-incident-hover]').forEach(el => {
        el.addEventListener('mouseenter', () => {
            const incidentId = el.dataset.incidentHover;
            AppState.hoveredIncident = AppState.incidents.find(i => i.id === incidentId);
            render();
        });
        el.addEventListener('mouseleave', () => {
            AppState.hoveredIncident = null;
            render();
        });
    });
}


// ===================== THEME =====================
function applyTheme() {
    document.body.className = `theme-${AppState.theme}`;
}

function updateLanguageButtons() {
    document.querySelectorAll('.lang-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.lang === AppState.language);
    });
}

// ===================== INITIALIZATION =====================
document.addEventListener('DOMContentLoaded', () => {
    // Set initial selected store
    AppState.selectedStore = AppState.stores[0];
    
    // Initial render
    render();
    
    // Update time every minute
    setInterval(renderCurrentTime, 60000);
});