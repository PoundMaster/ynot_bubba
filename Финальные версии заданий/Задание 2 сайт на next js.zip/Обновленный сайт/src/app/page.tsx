'use client';

import React, { useState, useEffect, createContext, useContext } from 'react';
import './task-manager.css';

// Types
interface Task {
  id: string;
  text: string;
  completed: boolean;
  isMandatory: boolean;
  completedDate?: string;
}

interface Notification {
  id: string;
  from: string;
  message: string;
  type: string;
  date: string;
  read: boolean;
}

interface Order {
  id: string;
  date: string;
  price: number;
  status: 'on the way' | 'delivered' | 'returned' | 'refunded' | 'late' | 'cancelled';
  items: { name: string; quantity: number; price: number }[];
}

interface Incident {
  id: string;
  type: string;
  clientName: string;
  description: string;
  detailedDescription?: string;
  status: string;
  priority: string;
  date: string;
  assignedTo?: string;
  history: { date: string; action: string; by: string }[];
}

interface Product {
  id: string;
  name: string;
  amount: number;
  price: number;
  category: string;
}

interface Store {
  id: string;
  name: string;
  address: string;
  income: number;
  rating: number;
  auditStatus: string;
}

interface Employee {
  id: string;
  name: string;
  position: string;
  status: string;
}

interface Training {
  id: string;
  date: string;
  theme: string;
  participants: string;
  status: 'planned' | 'completed';
  rating?: number;
}

interface OrderRequest {
  id: string;
  storeName: string;
  productName: string;
  amount: number;
  status: 'pending' | 'approved' | 'denied';
  comment?: string;
  initialDate: string;
  processedDate?: string;
}

interface Shift {
  id: string;
  employeeName: string;
  date: string;
  time: string;
  position: string;
}

interface EmployeeShortageRequest {
  id: string;
  storeName: string;
  role: string;
  amount: number;
  neededBy: string;
  hasFiles: boolean;
  status: 'pending' | 'approved' | 'denied';
  comment?: string;
  date: string;
}

// Language Translations
const translations = {
  en: {
    appTitle: 'TaskFlow Pro',
    appSubtitle: 'Enterprise Management System',
    quickActions: 'Quick Actions',
    dailyReport: 'Daily Report',
    staffOverview: 'Staff Overview',
    inventoryCheck: 'Inventory Check',
    cashRegister: 'Cash Register',
    viewStoreMetrics: '📈 View Store Metrics & Shifts',
    weeklyIncome: 'Weekly Income Overview',
    dailyRevenue: 'Daily Revenue',
    customersToday: 'Customers Today',
    avgTransaction: 'Avg. Transaction',
    inventoryHealth: 'Inventory Health',
    notifications: 'Notifications & Actions',
    backDashboard: '← Back to Dashboard',
    storeMetrics: 'Store Metrics',
    totalRevenue: 'Total Revenue (Month)',
    avgDailySales: 'Average Daily Sales',
    customerSatisfaction: 'Customer Satisfaction',
    returnRate: 'Return Rate',
    employeeShifts: 'Employee Shifts',
    addShift: '+ Add Shift',
    employee: 'Employee',
    date: 'Date',
    time: 'Time',
    position: 'Position',
    addNewShift: 'Add New Shift',
    employeeName: 'Employee Name',
    enterEmployeeName: 'Enter employee name',
    cancel: 'Cancel',
    confirm: 'Confirm',
    nearbyStores: 'Nearby Stores Map',
    messagesManagers: 'Messages from Managers',
    storeOverview: 'Store Overview',
    compareStores: '📊 Compare All Stores',
    storeName: 'Store Name',
    todayIncome: "Today's Income",
    rating: 'Rating',
    audit: 'Audit',
    address: 'Address',
    auditStatus: 'Audit Status',
    passed: 'Passed',
    pending: 'Pending',
    failed: 'Failed',
    incomingRequests: 'Incoming Order Requests',
    product: 'Product',
    amount: 'Amount',
    addComment: 'Add comment...',
    deny: 'Deny',
    approve: 'Approve',
    storeComparison: 'Store Performance Comparison',
    close: 'Close',
    selectStore: 'Select Store:',
    employeeChanges: 'Employee Changes - 6 Month Overview',
    hired: 'Hired',
    fired: 'Fired',
    totalEmployees: 'Total Employees',
    testingPeriod: 'Testing Period',
    onVacation: 'On Vacation',
    activeRequests: 'Active Employee Requests',
    vacationRequest: 'Vacation Request',
    shiftChange: 'Shift Change',
    sickLeave: 'Sick Leave',
    trainingRequest: 'Training Request',
    approveCandidates: '📋 Approve Candidates & Handle Incidents',
    complaintsIncidents: 'Complaints & Incidents',
    plannedTrainings: 'Planned Trainings',
    theme: 'Theme',
    participants: 'Participants',
    status: 'Status',
    incidentDetails: 'Incident Details',
    historyChanges: 'History of Changes',
    detailedDescription: 'Detailed Description',
    assignEmployee: 'Assign Employee',
    selectEmployee: 'Select employee...',
    closeIncident: 'Close Incident',
    assign: 'Assign',
    searchProducts: 'Search products...',
    bonusBalance: 'Bonus Balance',
    pts: 'pts',
    quickLinks: 'Quick Links',
    cart: 'Cart',
    orderHistory: 'Order History',
    favorites: 'Favorites',
    coupons: 'Coupons',
    settings: 'Settings',
    recommended: 'Recommended For You',
    addToCart: 'Add to Cart',
    orderUpdates: 'Order Updates',
    myOrders: 'My Orders',
    orderId: 'Order ID',
    price: 'Price',
    actions: 'Actions',
    onTheWay: 'on the way',
    delivered: 'delivered',
    returned: 'returned',
    refunded: 'refunded',
    late: 'late',
    cancelled: 'cancelled',
    reorder: 'Reorder',
    refund: 'Refund',
    createNewOrder: '+ Create New Order',
    orderDetails: 'Order Details',
    estimatedArrival: 'Estimated Arrival',
    items: 'Items',
    leaveReview: 'Leave a Review',
    submitReview: 'Submit Review',
    refundInfo: 'Refund Information',
    selectOrder: 'Select an order to view details',
    availableProducts: 'Available Products',
    yourCart: 'Your Cart',
    useBonus: 'Use',
    bonusPoints: 'bonus points',
    total: 'Total:',
    paymentInfo: 'Payment Information',
    placeOrder: 'Place Order',
    emptyCart: 'Your cart is empty',
    todoList: 'TODO List',
    addTask: '+ Add',
    addTaskPlaceholder: 'Add new task...',
    required: 'Required',
    sendReport: '📊 Send Daily Report to Store Manager',
    orderProducts: '📦 Order Products',
    reportSent: 'Report sent successfully!',
    lowStock: 'Low Stock Products (<5 units)',
    left: 'left',
    registerIncident: 'Register Incident',
    incidentType: 'Incident Type',
    technical: 'Technical',
    clientRelated: 'Client-related',
    clientNameSurname: 'Client Name & Surname',
    enterClientName: 'Enter client name (if applicable)',
    shortDescription: 'Short Description',
    briefDescription: 'Brief description',
    fullDetails: 'Full details of the incident',
    attachFiles: '📎 Attach Files (UI Only)',
    registerIncidentBtn: 'Register Incident',
    incidentHistory: 'Incident History (This Month)',
    open: 'Open',
    resolved: 'Resolved',
    inProgress: 'In Progress',
    selectProduct: 'Select product...',
    sendRequest: 'Send Request',
    employeeShortage: '👥 Request Employee Recruitment',
    recruitmentRequest: 'Employee Recruitment Request',
    employeeRole: 'Employee Role',
    enterRole: 'Enter role (e.g., Cashier)',
    workersNeeded: 'Number of Workers Needed',
    neededBy: 'Needed By',
    processTimeComparison: 'Order Processing Time Comparison',
    comparePeriod: 'Compare Period',
    pastMonth: 'Past Month',
    allTime: 'All Time',
    avgProcessTime: 'Avg. Process Time',
    days: 'days',
    orderRequestComparison: '📊 Compare Request Processing Time',
    employeeShortageRequests: 'Employee Shortage Requests',
    process: 'Process',
    comment: 'Comment',
  },
  ru: {
    appTitle: 'TaskFlow Pro',
    appSubtitle: 'Система управления предприятием',
    quickActions: 'Быстрые действия',
    dailyReport: 'Дневной отчёт',
    staffOverview: 'Обзор персонала',
    inventoryCheck: 'Проверка запасов',
    cashRegister: 'Касса',
    viewStoreMetrics: '📈 Метрики магазина и смены',
    weeklyIncome: 'Обзор недельного дохода',
    dailyRevenue: 'Дневная выручка',
    customersToday: 'Клиентов сегодня',
    avgTransaction: 'Ср. транзакция',
    inventoryHealth: 'Состояние запасов',
    notifications: 'Уведомления и действия',
    backDashboard: '← Назад к панели',
    storeMetrics: 'Метрики магазина',
    totalRevenue: 'Выручка за месяц',
    avgDailySales: 'Ср. дневные продажи',
    customerSatisfaction: 'Удовлетворённость',
    returnRate: 'Процент возвратов',
    employeeShifts: 'Смены сотрудников',
    addShift: '+ Добавить смену',
    employee: 'Сотрудник',
    date: 'Дата',
    time: 'Время',
    position: 'Должность',
    addNewShift: 'Добавить новую смену',
    employeeName: 'Имя сотрудника',
    enterEmployeeName: 'Введите имя сотрудника',
    cancel: 'Отмена',
    confirm: 'Подтвердить',
    nearbyStores: 'Карта магазинов поблизости',
    messagesManagers: 'Сообщения от менеджеров',
    storeOverview: 'Обзор магазинов',
    compareStores: '📊 Сравнить все магазины',
    storeName: 'Название магазина',
    todayIncome: 'Доход сегодня',
    rating: 'Рейтинг',
    audit: 'Аудит',
    address: 'Адрес',
    auditStatus: 'Статус аудита',
    passed: 'Пройден',
    pending: 'На рассмотрении',
    failed: 'Не пройден',
    incomingRequests: 'Входящие запросы на заказ',
    product: 'Продукт',
    amount: 'Количество',
    addComment: 'Добавить комментарий...',
    deny: 'Отклонить',
    approve: 'Одобрить',
    storeComparison: 'Сравнение производительности магазинов',
    close: 'Закрыть',
    selectStore: 'Выберите магазин:',
    employeeChanges: 'Изменения персонала - Обзор за 6 месяцев',
    hired: 'Нанято',
    fired: 'Уволено',
    totalEmployees: 'Всего сотрудников',
    testingPeriod: 'На испытательном',
    onVacation: 'В отпуске',
    activeRequests: 'Активные запросы сотрудников',
    vacationRequest: 'Запрос на отпуск',
    shiftChange: 'Смена смены',
    sickLeave: 'Больничный',
    trainingRequest: 'Запрос на обучение',
    approveCandidates: '📋 Одобрить кандидатов и инциденты',
    complaintsIncidents: 'Жалобы и инциденты',
    plannedTrainings: 'Запланированные обучения',
    theme: 'Тема',
    participants: 'Участники',
    status: 'Статус',
    incidentDetails: 'Детали инцидента',
    historyChanges: 'История изменений',
    detailedDescription: 'Подробное описание',
    assignEmployee: 'Назначить сотрудника',
    selectEmployee: 'Выберите сотрудника...',
    closeIncident: 'Закрыть инцидент',
    assign: 'Назначить',
    searchProducts: 'Поиск продуктов...',
    bonusBalance: 'Бонусный баланс',
    pts: 'баллов',
    quickLinks: 'Быстрые ссылки',
    cart: 'Корзина',
    orderHistory: 'История заказов',
    favorites: 'Избранное',
    coupons: 'Купоны',
    settings: 'Настройки',
    recommended: 'Рекомендуем',
    addToCart: 'В корзину',
    orderUpdates: 'Обновления заказов',
    myOrders: 'Мои заказы',
    orderId: 'ID заказа',
    price: 'Цена',
    actions: 'Действия',
    onTheWay: 'в пути',
    delivered: 'доставлен',
    returned: 'возвращён',
    refunded: 'возврат средств',
    late: 'задержка',
    cancelled: 'отменён',
    reorder: 'Повторить',
    refund: 'Возврат',
    createNewOrder: '+ Создать новый заказ',
    orderDetails: 'Детали заказа',
    estimatedArrival: 'Ожидаемое прибытие',
    items: 'Товары',
    leaveReview: 'Оставить отзыв',
    submitReview: 'Отправить отзыв',
    refundInfo: 'Информация о возврате',
    selectOrder: 'Выберите заказ для просмотра',
    availableProducts: 'Доступные продукты',
    yourCart: 'Ваша корзина',
    useBonus: 'Использовать',
    bonusPoints: 'бонусных баллов',
    total: 'Итого:',
    paymentInfo: 'Информация об оплате',
    placeOrder: 'Оформить заказ',
    emptyCart: 'Ваша корзина пуста',
    todoList: 'Список задач',
    addTask: '+ Добавить',
    addTaskPlaceholder: 'Добавить новую задачу...',
    required: 'Обязательно',
    sendReport: '📊 Отправить дневной отчёт менеджеру',
    orderProducts: '📦 Заказать продукты',
    reportSent: 'Отчёт успешно отправлен!',
    lowStock: 'Продукты с низким запасом (<5 шт)',
    left: 'осталось',
    registerIncident: 'Регистрация инцидента',
    incidentType: 'Тип инцидента',
    technical: 'Технический',
    clientRelated: 'Связанный с клиентом',
    clientNameSurname: 'Имя и фамилия клиента',
    enterClientName: 'Введите имя клиента (если применимо)',
    shortDescription: 'Краткое описание',
    briefDescription: 'Краткое описание',
    fullDetails: 'Полные детали инцидента',
    attachFiles: '📎 Прикрепить файлы (UI)',
    registerIncidentBtn: 'Зарегистрировать инцидент',
    incidentHistory: 'История инцидентов (этот месяц)',
    open: 'Открыт',
    resolved: 'Решён',
    inProgress: 'В процессе',
    selectProduct: 'Выберите продукт...',
    sendRequest: 'Отправить запрос',
    employeeShortage: '👥 Запрос на найм сотрудников',
    recruitmentRequest: 'Запрос на найм сотрудников',
    employeeRole: 'Должность сотрудника',
    enterRole: 'Введите должность (напр., Кассир)',
    workersNeeded: 'Требуется сотрудников',
    neededBy: 'Требуется к',
    processTimeComparison: 'Сравнение времени обработки заказов',
    comparePeriod: 'Период сравнения',
    pastMonth: 'За месяц',
    allTime: 'За всё время',
    avgProcessTime: 'Ср. время обработки',
    days: 'дней',
    orderRequestComparison: '📊 Сравнить время обработки',
    employeeShortageRequests: 'Запросы на найм',
    process: 'Обработать',
    comment: 'Комментарий',
  }
};

// Context types
type Language = 'en' | 'ru';
type Theme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const ThemeContext = createContext<ThemeContextType | null>(null);
const LanguageContext = createContext<LanguageContextType | null>(null);

const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within ThemeProvider');
  return context;
};

const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
};

// Global State Context
interface AppState {
  tasks: Task[];
  notifications: Notification[];
  orders: Order[];
  incidents: Incident[];
  products: Product[];
  stores: Store[];
  employees: Employee[];
  trainings: Training[];
  orderRequests: OrderRequest[];
  shifts: Shift[];
  employeeShortageRequests: EmployeeShortageRequest[];
  updateState: (key: string, value: any) => void;
}

const AppContext = createContext<AppState | null>(null);

const useAppState = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppState must be used within AppProvider');
  return context;
};

// Initial Data with 2026 dates
const initialTasks: Task[] = [
  { id: '1', text: 'Check inventory levels', completed: false, isMandatory: true },
  { id: '2', text: 'Review daily sales report', completed: false, isMandatory: true },
  { id: '3', text: 'Verify product displays', completed: false, isMandatory: true },
  { id: '4', text: 'Contact supplier about delivery', completed: false, isMandatory: false },
];

const initialNotifications: Notification[] = [
  { id: '1', from: 'HQ Admin', message: 'New pricing policy effective next week', type: 'info', date: '2026-01-15', read: false },
  { id: '2', from: 'Product Manager', message: 'Low stock alert: Milk (3 units left)', type: 'warning', date: '2026-01-15', read: false },
  { id: '3', from: 'HR Specialist', message: 'Employee shift change approved', type: 'success', date: '2026-01-14', read: true },
  { id: '4', from: 'Store Manager', message: 'Weekly meeting rescheduled to Friday', type: 'info', date: '2026-01-14', read: false },
  { id: '5', from: 'HQ Admin', message: 'Audit scheduled for next month', type: 'warning', date: '2026-01-13', read: true },
];

const initialOrders: Order[] = [
  { id: 'ORD-001', date: '2026-01-15', price: 156.99, status: 'on the way', items: [{ name: 'Organic Coffee', quantity: 2, price: 24.99 }, { name: 'Fresh Bread', quantity: 3, price: 8.99 }] },
  { id: 'ORD-002', date: '2026-01-14', price: 89.50, status: 'delivered', items: [{ name: 'Green Tea Set', quantity: 1, price: 45.00 }, { name: 'Honey', quantity: 2, price: 22.25 }] },
  { id: 'ORD-003', date: '2026-01-13', price: 234.00, status: 'delivered', items: [{ name: 'Premium Olive Oil', quantity: 3, price: 78.00 }] },
  { id: 'ORD-004', date: '2026-01-12', price: 45.99, status: 'returned', items: [{ name: 'Almond Butter', quantity: 2, price: 22.99 }] },
  { id: 'ORD-005', date: '2026-01-11', price: 178.25, status: 'refunded', items: [{ name: 'Protein Bars Pack', quantity: 5, price: 35.65 }] },
  { id: 'ORD-006', date: '2026-01-10', price: 67.80, status: 'late', items: [{ name: 'Rice Crackers', quantity: 4, price: 16.95 }] },
  { id: 'ORD-007', date: '2026-01-09', price: 299.99, status: 'cancelled', items: [{ name: 'Gift Basket Premium', quantity: 1, price: 299.99 }] },
];

const initialIncidents: Incident[] = [
  { id: 'INC-001', type: 'client-related', clientName: 'John Smith', description: 'Customer complaint about expired product', detailedDescription: 'Customer found expired milk on shelf and requested refund. Product was 3 days past expiration date.', status: 'open', priority: 'high', date: '2026-01-15', history: [{ date: '2026-01-15', action: 'Incident created', by: 'Product Manager' }] },
  { id: 'INC-002', type: 'technical', clientName: 'Maria Garcia', description: 'POS system malfunction', detailedDescription: 'Payment terminal stopped working during peak hours, causing delays.', status: 'in progress', priority: 'medium', date: '2026-01-14', history: [{ date: '2026-01-14', action: 'Incident created', by: 'Store Manager' }, { date: '2026-01-14', action: 'Assigned to IT Support', by: 'HR Specialist' }] },
  { id: 'INC-003', type: 'employee', clientName: 'N/A', description: 'Staff shortage during shift', detailedDescription: 'Two employees called in sick, causing understaffing issues.', status: 'resolved', priority: 'low', date: '2026-01-13', history: [{ date: '2026-01-13', action: 'Incident created', by: 'Store Manager' }, { date: '2026-01-13', action: 'Temporary staff assigned', by: 'HR Specialist' }, { date: '2026-01-14', action: 'Incident resolved', by: 'Store Manager' }] },
  { id: 'INC-004', type: 'product', clientName: 'David Lee', description: 'Product quality issue', detailedDescription: 'Customer reported damaged packaging on premium items.', status: 'open', priority: 'medium', date: '2026-01-15', history: [{ date: '2026-01-15', action: 'Incident created', by: 'Product Manager' }] },
];

const initialProducts: Product[] = [
  { id: 'P001', name: 'Organic Milk', amount: 3, price: 4.99, category: 'Dairy' },
  { id: 'P002', name: 'Fresh Bread', amount: 2, price: 3.49, category: 'Bakery' },
  { id: 'P003', name: 'Free Range Eggs', amount: 4, price: 6.99, category: 'Dairy' },
  { id: 'P004', name: 'Premium Coffee', amount: 8, price: 12.99, category: 'Beverages' },
  { id: 'P005', name: 'Green Tea', amount: 15, price: 5.99, category: 'Beverages' },
  { id: 'P006', name: 'Olive Oil', amount: 1, price: 15.99, category: 'Pantry' },
  { id: 'P007', name: 'Pasta', amount: 20, price: 2.99, category: 'Pantry' },
  { id: 'P008', name: 'Tomato Sauce', amount: 2, price: 3.49, category: 'Pantry' },
  { id: 'P009', name: 'Chicken Breast', amount: 4, price: 9.99, category: 'Meat' },
  { id: 'P010', name: 'Salmon Fillet', amount: 3, price: 14.99, category: 'Seafood' },
  { id: 'P011', name: 'Greek Yogurt', amount: 2, price: 5.49, category: 'Dairy' },
  { id: 'P012', name: 'Almonds', amount: 6, price: 8.99, category: 'Snacks' },
];

const initialStores: Store[] = [
  { id: 'S001', name: 'Downtown Store', address: '123 Main St', income: 15420, rating: 4.5, auditStatus: 'Passed' },
  { id: 'S002', name: 'Mall Branch', address: '456 Shopping Ave', income: 12850, rating: 4.2, auditStatus: 'Pending' },
  { id: 'S003', name: 'Westside Location', address: '789 West Rd', income: 9340, rating: 4.7, auditStatus: 'Passed' },
  { id: 'S004', name: 'Harbor Store', address: '321 Port Blvd', income: 11200, rating: 4.0, auditStatus: 'Failed' },
  { id: 'S005', name: 'University Branch', address: '555 College Dr', income: 8900, rating: 4.3, auditStatus: 'Passed' },
];

const initialEmployees: Employee[] = [
  { id: 'E001', name: 'Alice Johnson', position: 'Senior Cashier', status: 'active' },
  { id: 'E002', name: 'Bob Williams', position: 'Stock Clerk', status: 'testing' },
  { id: 'E003', name: 'Carol Davis', position: 'Department Manager', status: 'vacation' },
  { id: 'E004', name: 'David Brown', position: 'Cashier', status: 'active' },
  { id: 'E005', name: 'Eva Martinez', position: 'Customer Service', status: 'testing' },
];

const initialTrainings: Training[] = [
  { id: 'T001', date: '2026-01-20', theme: 'Customer Service Excellence', participants: 'Bob Williams, Eva Martinez', status: 'planned' },
  { id: 'T002', date: '2026-01-18', theme: 'Product Knowledge Update', participants: 'All Staff', status: 'completed', rating: 4.5 },
  { id: 'T003', date: '2026-01-25', theme: 'Safety Protocols', participants: 'David Brown, Alice Johnson', status: 'planned' },
  { id: 'T004', date: '2026-01-10', theme: 'New POS System Training', participants: 'All Cashiers', status: 'completed', rating: 4.8 },
];

// Updated with initialDate and processedDate, plus 6 more closed requests (2 per store)
const initialOrderRequests: OrderRequest[] = [
  { id: 'REQ-001', storeName: 'Downtown Store', productName: 'Organic Milk', amount: 50, status: 'pending', initialDate: '2026-01-15' },
  { id: 'REQ-002', storeName: 'Mall Branch', productName: 'Premium Coffee', amount: 30, status: 'pending', initialDate: '2026-01-14' },
  { id: 'REQ-003', storeName: 'Westside Location', productName: 'Fresh Bread', amount: 40, status: 'approved', comment: 'Approved - delivery in 3 days', initialDate: '2026-01-10', processedDate: '2026-01-12' },
  { id: 'REQ-004', storeName: 'Harbor Store', productName: 'Olive Oil', amount: 25, status: 'denied', comment: 'Budget constraints this month', initialDate: '2026-01-08', processedDate: '2026-01-10' },
  // Additional closed requests - 2 per store
  { id: 'REQ-005', storeName: 'Downtown Store', productName: 'Greek Yogurt', amount: 35, status: 'approved', comment: 'Express delivery arranged', initialDate: '2026-01-05', processedDate: '2026-01-06' },
  { id: 'REQ-006', storeName: 'Downtown Store', productName: 'Chicken Breast', amount: 20, status: 'denied', comment: 'Supplier shortage', initialDate: '2026-01-03', processedDate: '2026-01-05' },
  { id: 'REQ-007', storeName: 'Mall Branch', productName: 'Salmon Fillet', amount: 15, status: 'approved', comment: 'Weekly delivery scheduled', initialDate: '2026-01-07', processedDate: '2026-01-09' },
  { id: 'REQ-008', storeName: 'Mall Branch', productName: 'Almonds', amount: 45, status: 'approved', comment: 'Standard approval', initialDate: '2026-01-02', processedDate: '2026-01-04' },
  { id: 'REQ-009', storeName: 'Westside Location', productName: 'Pasta', amount: 60, status: 'denied', comment: 'Exceeded monthly quota', initialDate: '2026-01-04', processedDate: '2026-01-06' },
  { id: 'REQ-010', storeName: 'Harbor Store', productName: 'Tomato Sauce', amount: 30, status: 'approved', comment: 'Rush order approved', initialDate: '2026-01-06', processedDate: '2026-01-07' },
];

const initialShifts: Shift[] = [
  { id: 'SH-001', employeeName: 'Alice Johnson', date: '2026-01-16', time: '08:00 - 16:00', position: 'Senior Cashier' },
  { id: 'SH-002', employeeName: 'Bob Williams', date: '2026-01-16', time: '10:00 - 18:00', position: 'Stock Clerk' },
  { id: 'SH-003', employeeName: 'David Brown', date: '2026-01-17', time: '08:00 - 16:00', position: 'Cashier' },
  { id: 'SH-004', employeeName: 'Eva Martinez', date: '2026-01-17', time: '12:00 - 20:00', position: 'Customer Service' },
];

const initialEmployeeShortageRequests: EmployeeShortageRequest[] = [];

// Main App Component
export default function TaskManagerApp() {
  const [currentRole, setCurrentRole] = useState<string>('store-manager');
  const [theme, setTheme] = useState<Theme>('light');
  const [language, setLanguage] = useState<Language>('en');
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [incidents, setIncidents] = useState<Incident[]>(initialIncidents);
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [stores] = useState<Store[]>(initialStores);
  const [employees] = useState<Employee[]>(initialEmployees);
  const [trainings, setTrainings] = useState<Training[]>(initialTrainings);
  const [orderRequests, setOrderRequests] = useState<OrderRequest[]>(initialOrderRequests);
  const [shifts, setShifts] = useState<Shift[]>(initialShifts);
  const [employeeShortageRequests, setEmployeeShortageRequests] = useState<EmployeeShortageRequest[]>(initialEmployeeShortageRequests);

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  const updateState = (key: string, value: any) => {
    switch (key) {
      case 'tasks': setTasks(value); break;
      case 'notifications': setNotifications(value); break;
      case 'orders': setOrders(value); break;
      case 'incidents': setIncidents(value); break;
      case 'products': setProducts(value); break;
      case 'trainings': setTrainings(value); break;
      case 'orderRequests': setOrderRequests(value); break;
      case 'shifts': setShifts(value); break;
      case 'employeeShortageRequests': setEmployeeShortageRequests(value); break;
    }
  };

  const state: AppState = {
    tasks, notifications, orders, incidents, products, stores, employees, trainings, orderRequests, shifts, employeeShortageRequests, updateState
  };

  const roles = [
    { id: 'store-manager', name: 'Store Manager', icon: '🏪' },
    { id: 'hq-admin', name: 'HQ Administrator', icon: '🏢' },
    { id: 'hr-specialist', name: 'HR Specialist', icon: '👥' },
    { id: 'client', name: 'Client', icon: '🛒' },
    { id: 'product-manager', name: 'Product Manager', icon: '📦' },
  ];

  // Apply theme class to body
  useEffect(() => {
    document.body.className = `theme-${theme}`;
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <LanguageContext.Provider value={{ language, setLanguage, t }}>
        <AppContext.Provider value={state}>
          <div className={`app-container theme-${theme}`}>
            <header className="app-header">
              <div className="header-left">
                <h1 className="app-title">{t('appTitle')}</h1>
                <span className="app-subtitle">{t('appSubtitle')}</span>
              </div>
              
              <div className="header-controls">
                <nav className="theme-nav switch-nav">
                  <button
                    className={`theme-btn switch-btn ${theme === 'light' ? 'active' : ''}`}
                    onClick={() => setTheme('light')}
                    title="Light Theme"
                  >
                    <span className="theme-icon">☀️</span>
                  </button>
                  <button
                    className={`theme-btn switch-btn ${theme === 'dark' ? 'active' : ''}`}
                    onClick={() => setTheme('dark')}
                    title="Dark Theme"
                  >
                    <span className="theme-icon">🌙</span>
                  </button>
                </nav>

                <nav className="role-nav">
                  {roles.map((role) => (
                    <button
                      key={role.id}
                      className={`role-btn ${currentRole === role.id ? 'active' : ''}`}
                      onClick={() => setCurrentRole(role.id)}
                    >
                      <span className="role-icon">{role.icon}</span>
                      <span className="role-name">{role.name}</span>
                    </button>
                  ))}
                </nav>

                <nav className="lang-nav switch-nav">
                  <button
                    className={`lang-btn switch-btn ${language === 'en' ? 'active' : ''}`}
                    onClick={() => setLanguage('en')}
                    title="English"
                  >
                    <span className="lang-icon">🇺🇸</span>
                  </button>
                  <button
                    className={`lang-btn switch-btn ${language === 'ru' ? 'active' : ''}`}
                    onClick={() => setLanguage('ru')}
                    title="Русский"
                  >
                    <span className="lang-icon">🇷🇺</span>
                  </button>
                </nav>
              </div>
              
              <div className="header-right">
                <span className="current-time">{new Date().toLocaleDateString(language === 'ru' ? 'ru-RU' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </div>
            </header>

            <main className="main-content">
              <div className={`role-page ${currentRole === 'store-manager' ? 'active' : ''}`}>
                <StoreManagerPage />
              </div>
              <div className={`role-page ${currentRole === 'hq-admin' ? 'active' : ''}`}>
                <HQAdminPage />
              </div>
              <div className={`role-page ${currentRole === 'hr-specialist' ? 'active' : ''}`}>
                <HRSpecialistPage />
              </div>
              <div className={`role-page ${currentRole === 'client' ? 'active' : ''}`}>
                <ClientPage />
              </div>
              <div className={`role-page ${currentRole === 'product-manager' ? 'active' : ''}`}>
                <ProductManagerPage />
              </div>
            </main>
          </div>
        </AppContext.Provider>
      </LanguageContext.Provider>
    </ThemeContext.Provider>
  );
}

// Store Manager Page
function StoreManagerPage() {
  const { notifications, stores, shifts, employeeShortageRequests, updateState } = useAppState();
  const { t } = useLanguage();
  const [showSecondPage, setShowSecondPage] = useState(false);
  const [showAddShiftModal, setShowAddShiftModal] = useState(false);
  const [showShortageModal, setShowShortageModal] = useState(false);
  const [newShift, setNewShift] = useState({ employeeName: '', date: '', time: '', position: '' });
  const [newShortage, setNewShortage] = useState({ role: '', amount: 1, neededBy: '', hasFiles: false });

  const weeklyIncome = [12400, 15600, 13800, 16200, 14500, 17800, 15420];
  const weekDays = language => ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const maxIncome = Math.max(...weeklyIncome);

  const kpiData = [
    { title: t('dailyRevenue'), value: '$15,420', change: '+12%', positive: true },
    { title: t('customersToday'), value: '847', change: '+5%', positive: true },
    { title: t('avgTransaction'), value: '$48.50', change: '-2%', positive: false },
    { title: t('inventoryHealth'), value: '94%', change: '+3%', positive: true },
  ];

  const quickActions = [
    { icon: '📊', label: t('dailyReport') },
    { icon: '👥', label: t('staffOverview') },
    { icon: '📦', label: t('inventoryCheck') },
    { icon: '💰', label: t('cashRegister') },
  ];

  const storeNotifications = notifications.filter(n => n.from === 'Product Manager' || n.from === 'HQ Admin' || n.from === 'HR Specialist');

  const handleAddShift = () => {
    if (newShift.employeeName && newShift.date && newShift.time && newShift.position) {
      const shift: Shift = {
        id: `SH-${String(shifts.length + 1).padStart(3, '0')}`,
        ...newShift
      };
      updateState('shifts', [...shifts, shift]);
      setNewShift({ employeeName: '', date: '', time: '', position: '' });
      setShowAddShiftModal(false);
    }
  };

  const handleSendShortageRequest = () => {
    if (newShortage.role && newShortage.amount > 0 && newShortage.neededBy) {
      const request: EmployeeShortageRequest = {
        id: `ESR-${String(employeeShortageRequests.length + 1).padStart(3, '0')}`,
        storeName: 'Downtown Store',
        role: newShortage.role,
        amount: newShortage.amount,
        neededBy: newShortage.neededBy,
        hasFiles: newShortage.hasFiles,
        status: 'pending',
        date: new Date().toISOString().split('T')[0]
      };
      updateState('employeeShortageRequests', [request, ...employeeShortageRequests]);
      setNewShortage({ role: '', amount: 1, neededBy: '', hasFiles: false });
      setShowShortageModal(false);
    }
  };

  return (
    <div className="store-manager-page">
      {!showSecondPage ? (
        <>
          <div className="sm-top-section">
            <div className="sm-quick-actions">
              <h3>{t('quickActions')}</h3>
              <div className="quick-actions-grid">
                {quickActions.map((action, i) => (
                  <button key={i} className="quick-action-btn">
                    <span className="action-icon">{action.icon}</span>
                    <span className="action-label">{action.label}</span>
                  </button>
                ))}
              </div>
              <button className="switch-page-btn" onClick={() => setShowSecondPage(true)}>
                {t('viewStoreMetrics')}
              </button>
            </div>

            <div className="sm-income-chart">
              <h3>{t('weeklyIncome')}</h3>
              <div className="bar-chart">
                {weeklyIncome.map((income, i) => (
                  <div key={i} className="bar-group">
                    <div className="bar-value">${(income / 1000).toFixed(1)}k</div>
                    <div 
                      className="bar" 
                      style={{ height: `${(income / maxIncome) * 200}px` }}
                    >
                      <div className="bar-inner"></div>
                    </div>
                    <div className="bar-label">{weekDays('en')[i]}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="sm-kpi-section">
            {kpiData.map((kpi, i) => (
              <div key={i} className="kpi-card">
                <div className="kpi-title">{kpi.title}</div>
                <div className="kpi-value">{kpi.value}</div>
                <div className={`kpi-change ${kpi.positive ? 'positive' : 'negative'}`}>
                  {kpi.positive ? '↑' : '↓'} {kpi.change}
                </div>
              </div>
            ))}
          </div>

          <div className="sm-bottom-section">
            <div className="sm-notifications">
              <h3>{t('notifications')}</h3>
              <div className="notifications-list">
                {storeNotifications.map((notif) => (
                  <div key={notif.id} className={`notification-item ${notif.read ? 'read' : ''}`}>
                    <div className="notif-header">
                      <span className="notif-from">{notif.from}</span>
                      <span className="notif-date">{notif.date}</span>
                    </div>
                    <div className="notif-message">{notif.message}</div>
                    <span className={`notif-type ${notif.type}`}>{notif.type}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="sm-second-page">
          <button className="back-btn" onClick={() => setShowSecondPage(false)}>
            {t('backDashboard')}
          </button>

          <div className="sm-metrics-section">
            <h2>{t('storeMetrics')}</h2>
            <div className="metrics-grid">
              <div className="metric-card">
                <h4>{t('totalRevenue')}</h4>
                <div className="metric-value">$124,500</div>
              </div>
              <div className="metric-card">
                <h4>{t('avgDailySales')}</h4>
                <div className="metric-value">$4,150</div>
              </div>
              <div className="metric-card">
                <h4>{t('customerSatisfaction')}</h4>
                <div className="metric-value">4.6/5.0</div>
              </div>
              <div className="metric-card">
                <h4>{t('returnRate')}</h4>
                <div className="metric-value">2.3%</div>
              </div>
            </div>
          </div>

          <div className="sm-shifts-section">
            <div className="shifts-header">
              <h2>{t('employeeShifts')}</h2>
              <div className="shifts-buttons">
                <button className="shortage-btn" onClick={() => setShowShortageModal(true)}>
                  {t('employeeShortage')}
                </button>
                <button className="add-shift-btn" onClick={() => setShowAddShiftModal(true)}>
                  {t('addShift')}
                </button>
              </div>
            </div>
            <div className="shift-calendar">
              <div className="calendar-header">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                  <div key={day} className="calendar-day-header">{day}</div>
                ))}
              </div>
              <div className="calendar-body">
                {Array.from({ length: 7 }, (_, i) => {
                  const dayShifts = shifts.filter(s => {
                    const shiftDate = new Date(s.date);
                    return shiftDate.getDay() === (i + 1) % 7;
                  });
                  return (
                    <div key={i} className="calendar-day">
                      <div className="day-number">{i + 15}</div>
                      {dayShifts.map(shift => (
                        <div key={shift.id} className="shift-item">
                          <span className="shift-employee">{shift.employeeName}</span>
                          <span className="shift-time">{shift.time}</span>
                        </div>
                      ))}
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="shifts-table">
              <table>
                <thead>
                  <tr>
                    <th>{t('employee')}</th>
                    <th>{t('date')}</th>
                    <th>{t('time')}</th>
                    <th>{t('position')}</th>
                  </tr>
                </thead>
                <tbody>
                  {shifts.map(shift => (
                    <tr key={shift.id}>
                      <td>{shift.employeeName}</td>
                      <td>{shift.date}</td>
                      <td>{shift.time}</td>
                      <td>{shift.position}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {showAddShiftModal && (
        <div className="modal-overlay" onClick={() => setShowAddShiftModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h3>{t('addNewShift')}</h3>
            <div className="form-group">
              <label>{t('employeeName')}</label>
              <input 
                type="text" 
                value={newShift.employeeName}
                onChange={e => setNewShift({...newShift, employeeName: e.target.value})}
                placeholder={t('enterEmployeeName')}
              />
            </div>
            <div className="form-group">
              <label>{t('date')}</label>
              <input 
                type="date" 
                value={newShift.date}
                onChange={e => setNewShift({...newShift, date: e.target.value})}
              />
            </div>
            <div className="form-group">
              <label>{t('time')}</label>
              <input 
                type="text" 
                value={newShift.time}
                onChange={e => setNewShift({...newShift, time: e.target.value})}
                placeholder="e.g., 08:00 - 16:00"
              />
            </div>
            <div className="form-group">
              <label>{t('position')}</label>
              <input 
                type="text" 
                value={newShift.position}
                onChange={e => setNewShift({...newShift, position: e.target.value})}
                placeholder={t('position')}
              />
            </div>
            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setShowAddShiftModal(false)}>{t('cancel')}</button>
              <button className="confirm-btn" onClick={handleAddShift}>{t('confirm')}</button>
            </div>
          </div>
        </div>
      )}

      {showShortageModal && (
        <div className="modal-overlay" onClick={() => setShowShortageModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h3>{t('recruitmentRequest')}</h3>
            <div className="form-group">
              <label>{t('employeeRole')}</label>
              <input 
                type="text" 
                value={newShortage.role}
                onChange={e => setNewShortage({...newShortage, role: e.target.value})}
                placeholder={t('enterRole')}
              />
            </div>
            <div className="form-group">
              <label>{t('workersNeeded')}</label>
              <input 
                type="number" 
                min="1"
                value={newShortage.amount}
                onChange={e => setNewShortage({...newShortage, amount: parseInt(e.target.value) || 1})}
              />
            </div>
            <div className="form-group">
              <label>{t('neededBy')}</label>
              <input 
                type="date" 
                value={newShortage.neededBy}
                onChange={e => setNewShortage({...newShortage, neededBy: e.target.value})}
              />
            </div>
            <div className="form-group">
              <button className="attach-btn" onClick={() => setNewShortage({...newShortage, hasFiles: !newShortage.hasFiles})}>
                {t('attachFiles')} {newShortage.hasFiles ? '✓' : ''}
              </button>
            </div>
            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setShowShortageModal(false)}>{t('cancel')}</button>
              <button className="confirm-btn" onClick={handleSendShortageRequest}>{t('sendRequest')}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// HQ Admin Page
function HQAdminPage() {
  const { stores, notifications, orderRequests, updateState } = useAppState();
  const { t } = useLanguage();
  const [selectedStore, setSelectedStore] = useState<Store | null>(stores[0]);
  const [showCompareModal, setShowCompareModal] = useState(false);
  const [showProcessTimeModal, setShowProcessTimeModal] = useState(false);
  const [processTimePeriod, setProcessTimePeriod] = useState<'month' | 'all'>('month');
  const [requestComment, setRequestComment] = useState<{ [key: string]: string }>({});

  const storeWeeklyIncome = stores.map(s => ({
    name: s.name,
    income: [12000 + Math.random() * 5000, 13000 + Math.random() * 4000, 11000 + Math.random() * 6000, 14000 + Math.random() * 3000, 12000 + Math.random() * 5000, 15000 + Math.random() * 4000, s.income]
  }));

  const hqNotifications = notifications.filter(n => n.from === 'Store Manager' || n.from === 'HR Specialist');

  const handleRequest = (requestId: string, approve: boolean) => {
    const today = new Date().toISOString().split('T')[0];
    const updated = orderRequests.map(r => {
      if (r.id === requestId) {
        return {
          ...r,
          status: approve ? 'approved' : 'denied' as const,
          comment: requestComment[requestId] || '',
          processedDate: today
        };
      }
      return r;
    });
    updateState('orderRequests', updated);
  };

  // Calculate average process time per store
  const getStoreProcessTime = (storeName: string, period: 'month' | 'all') => {
    const storeRequests = orderRequests.filter(r => 
      r.storeName === storeName && 
      r.processedDate && 
      r.initialDate
    );
    
    if (storeRequests.length === 0) return 0;
    
    const totalDays = storeRequests.reduce((sum, r) => {
      const initial = new Date(r.initialDate);
      const processed = new Date(r.processedDate!);
      return sum + Math.ceil((processed.getTime() - initial.getTime()) / (1000 * 60 * 60 * 24));
    }, 0);
    
    return Math.round(totalDays / storeRequests.length * 10) / 10;
  };

  return (
    <div className="hq-admin-page">
      <div className="hq-top-section">
        <div className="hq-map-section">
          <h3>{t('nearbyStores')}</h3>
          <div className="store-map">
            <div className="map-container">
              {stores.map((store, i) => (
                <div 
                  key={store.id}
                  className={`map-marker ${selectedStore?.id === store.id ? 'selected' : ''}`}
                  style={{
                    left: `${20 + (i % 3) * 30}%`,
                    top: `${20 + Math.floor(i / 3) * 40}%`
                  }}
                  onClick={() => setSelectedStore(store)}
                >
                  <span className="marker-icon">📍</span>
                  <span className="marker-name">{store.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="hq-messages-section">
          <h3>{t('messagesManagers')}</h3>
          <div className="messages-list">
            {hqNotifications.map(notif => (
              <div key={notif.id} className="message-item">
                <div className="message-header">
                  <span className="message-from">{notif.from}</span>
                  <span className="message-date">{notif.date}</span>
                </div>
                <div className="message-content">{notif.message}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="hq-stores-section">
          <div className="stores-header">
            <h3>{t('storeOverview')}</h3>
            <button className="compare-btn" onClick={() => setShowCompareModal(true)}>
              {t('compareStores')}
            </button>
          </div>
          <div className="stores-table">
            <table>
              <thead>
                <tr>
                  <th>{t('storeName')}</th>
                  <th>{t('todayIncome')}</th>
                  <th>{t('rating')}</th>
                  <th>{t('audit')}</th>
                </tr>
              </thead>
              <tbody>
                {stores.map(store => (
                  <tr 
                    key={store.id}
                    className={selectedStore?.id === store.id ? 'selected' : ''}
                    onClick={() => setSelectedStore(store)}
                  >
                    <td>{store.name}</td>
                    <td>${store.income.toLocaleString()}</td>
                    <td>⭐ {store.rating}</td>
                    <td>
                      <span className={`audit-badge ${store.auditStatus.toLowerCase()}`}>
                        {store.auditStatus === 'Passed' ? t('passed') : store.auditStatus === 'Pending' ? t('pending') : t('failed')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {selectedStore && (
            <div className="store-details">
              <h4>{selectedStore.name} {t('details') || 'Details'}</h4>
              <div className="detail-row">
                <span>{t('address')}:</span>
                <span>{selectedStore.address}</span>
              </div>
              <div className="detail-row">
                <span>{t('todayIncome')}:</span>
                <span>${selectedStore.income.toLocaleString()}</span>
              </div>
              <div className="detail-row">
                <span>{t('rating')}:</span>
                <span>⭐ {selectedStore.rating}/5.0</span>
              </div>
              <div className="detail-row">
                <span>{t('auditStatus')}:</span>
                <span className={`audit-badge ${selectedStore.auditStatus.toLowerCase()}`}>
                  {selectedStore.auditStatus === 'Passed' ? t('passed') : selectedStore.auditStatus === 'Pending' ? t('pending') : t('failed')}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="hq-requests-section">
        <div className="requests-header">
          <h3>{t('incomingRequests')}</h3>
          <button className="process-time-btn" onClick={() => setShowProcessTimeModal(true)}>
            {t('orderRequestComparison')}
          </button>
        </div>
        <div className="requests-list">
          {orderRequests.map(request => (
            <div key={request.id} className={`request-item ${request.status}`}>
              <div className="request-info">
                <span className="request-id">{request.id}</span>
                <span className="request-store">{request.storeName}</span>
                <span className="request-product">{request.productName}</span>
                <span className="request-amount">×{request.amount}</span>
                <span className="request-initial-date">{request.initialDate}</span>
                {request.processedDate && <span className="request-processed-date">→ {request.processedDate}</span>}
                <span className={`request-status ${request.status}`}>{request.status === 'approved' ? t('approve') : request.status === 'denied' ? t('deny') : t('pending')}</span>
              </div>
              {request.status === 'pending' && (
                <div className="request-actions">
                  <input
                    type="text"
                    placeholder={t('addComment')}
                    value={requestComment[request.id] || ''}
                    onChange={e => setRequestComment({...requestComment, [request.id]: e.target.value})}
                    className="comment-input"
                  />
                  <button className="deny-btn" onClick={() => handleRequest(request.id, false)}>{t('deny')}</button>
                  <button className="approve-btn" onClick={() => handleRequest(request.id, true)}>{t('approve')}</button>
                </div>
              )}
              {request.comment && (
                <div className="request-comment">{t('comment')}: {request.comment}</div>
              )}
            </div>
          ))}
        </div>
      </div>

      {showCompareModal && (
        <div className="modal-overlay" onClick={() => setShowCompareModal(false)}>
          <div className="modal-content compare-modal" onClick={e => e.stopPropagation()}>
            <h3>{t('storeComparison')}</h3>
            <div className="compare-chart">
              <div className="grouped-bar-chart">
                {storeWeeklyIncome.map((store, i) => (
                  <div key={i} className="store-bars">
                    <div className="store-name-label">{store.name.split(' ')[0]}</div>
                    <div className="week-bars">
                      {store.income.map((inc, j) => (
                        <div 
                          key={j}
                          className="mini-bar"
                          style={{ height: `${(inc / 20000) * 100}px` }}
                          title={`$${Math.round(inc).toLocaleString()}`}
                        ></div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              <div className="chart-legend">
                <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
              </div>
            </div>
            <button className="close-modal-btn" onClick={() => setShowCompareModal(false)}>{t('close')}</button>
          </div>
        </div>
      )}

      {showProcessTimeModal && (
        <div className="modal-overlay" onClick={() => setShowProcessTimeModal(false)}>
          <div className="modal-content compare-modal process-time-modal" onClick={e => e.stopPropagation()}>
            <h3>{t('processTimeComparison')}</h3>
            <div className="period-toggle">
              <button 
                className={`period-btn ${processTimePeriod === 'month' ? 'active' : ''}`}
                onClick={() => setProcessTimePeriod('month')}
              >
                {t('pastMonth')}
              </button>
              <button 
                className={`period-btn ${processTimePeriod === 'all' ? 'active' : ''}`}
                onClick={() => setProcessTimePeriod('all')}
              >
                {t('allTime')}
              </button>
            </div>
            <div className="process-time-chart">
              {stores.map(store => {
                const avgTime = getStoreProcessTime(store.name, processTimePeriod);
                return (
                  <div key={store.id} className="process-time-item">
                    <div className="process-store-name">{store.name}</div>
                    <div className="process-bar-container">
                      <div 
                        className="process-bar" 
                        style={{ width: `${Math.min(avgTime * 10, 100)}%` }}
                      ></div>
                    </div>
                    <div className="process-time-value">{avgTime} {t('days')}</div>
                  </div>
                );
              })}
            </div>
            <button className="close-modal-btn" onClick={() => setShowProcessTimeModal(false)}>{t('close')}</button>
          </div>
        </div>
      )}
    </div>
  );
}

// HR Specialist Page
function HRSpecialistPage() {
  const { employees, notifications, incidents, trainings, updateState, stores, employeeShortageRequests } = useAppState();
  const { t } = useLanguage();
  const [showSecondPage, setShowSecondPage] = useState(false);
  const [selectedStore, setSelectedStore] = useState(stores[0].name);
  const [selectedIncident, setSelectedIncident] = useState<Incident | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [shortageComment, setShortageComment] = useState<{ [key: string]: string }>({});

  const hiredData = [5, 3, 4, 6, 2, 4];
  const firedData = [1, 2, 1, 3, 1, 2];
  const months = ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'];

  const employeeStats = {
    total: employees.length,
    testing: employees.filter(e => e.status === 'testing').length,
    fired: 2,
    vacation: employees.filter(e => e.status === 'vacation').length
  };

  const hrNotifications = notifications.filter(n => n.from === 'Store Manager' || n.from === 'HQ Admin');

  const activeRequests = [
    { id: 'REQ-HR-001', employee: 'Alice Johnson', type: t('vacationRequest'), status: 'pending' },
    { id: 'REQ-HR-002', employee: 'Bob Williams', type: t('shiftChange'), status: 'approved' },
    { id: 'REQ-HR-003', employee: 'David Brown', type: t('sickLeave'), status: 'pending' },
    { id: 'REQ-HR-004', employee: 'Eva Martinez', type: t('trainingRequest'), status: 'pending' },
  ];

  const handleAssignIncident = () => {
    if (selectedIncident && selectedEmployee) {
      const updated = incidents.map(i => {
        if (i.id === selectedIncident.id) {
          return {
            ...i,
            assignedTo: selectedEmployee,
            status: 'in progress',
            history: [...i.history, { date: new Date().toISOString().split('T')[0], action: `Assigned to ${selectedEmployee}`, by: 'HR Specialist' }]
          };
        }
        return i;
      });
      updateState('incidents', updated);
      setSelectedIncident(null);
      setSelectedEmployee('');
    }
  };

  const handleCloseIncident = () => {
    if (selectedIncident) {
      const updated = incidents.map(i => {
        if (i.id === selectedIncident.id) {
          return {
            ...i,
            status: 'resolved',
            history: [...i.history, { date: new Date().toISOString().split('T')[0], action: 'Incident closed', by: 'HR Specialist' }]
          };
        }
        return i;
      });
      updateState('incidents', updated);
      setSelectedIncident(null);
    }
  };

  const handleShortageRequest = (requestId: string, approve: boolean) => {
    // Update the shortage request
    const updatedRequests = employeeShortageRequests.map(r => {
      if (r.id === requestId) {
        return {
          ...r,
          status: approve ? 'approved' : 'denied' as const,
          comment: shortageComment[requestId] || ''
        };
      }
      return r;
    });
    updateState('employeeShortageRequests', updatedRequests);

    // Send notification to Store Manager
    const request = employeeShortageRequests.find(r => r.id === requestId);
    if (request) {
      const notif: Notification = {
        id: `N-${Date.now()}`,
        from: 'HR Specialist',
        message: `Employee shortage request ${approve ? 'approved' : 'denied'}: ${request.amount}x ${request.role}. ${shortageComment[requestId] || ''}`,
        type: approve ? 'success' : 'warning',
        date: new Date().toISOString().split('T')[0],
        read: false
      };
      updateState('notifications', [notif, ...notifications]);
    }
  };

  return (
    <div className="hr-specialist-page">
      {!showSecondPage ? (
        <>
          <div className="hr-top-section">
            <div className="store-selector">
              <label>{t('selectStore')}</label>
              <select value={selectedStore} onChange={e => setSelectedStore(e.target.value)}>
                {stores.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
              </select>
            </div>
            <div className="employee-graph">
              <h3>{t('employeeChanges')}</h3>
              <div className="line-chart">
                <div className="chart-y-axis">
                  {[6, 5, 4, 3, 2, 1, 0].map(n => <span key={n}>{n}</span>)}
                </div>
                <div className="chart-area">
                  {months.map((month, i) => (
                    <div key={month} className="chart-column">
                      <div className="bar-group-hr">
                        <div className="hired-bar" style={{ height: `${hiredData[i] * 25}px` }}></div>
                        <div className="fired-bar" style={{ height: `${firedData[i] * 25}px` }}></div>
                      </div>
                      <span className="month-label">{month}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="chart-legend-hr">
                <span className="legend-item"><span className="legend-color hired"></span> {t('hired')}</span>
                <span className="legend-item"><span className="legend-color fired"></span> {t('fired')}</span>
              </div>
            </div>
          </div>

          <div className="hr-stats-cards">
            <div className="stat-card">
              <div className="stat-icon">👥</div>
              <div className="stat-info">
                <span className="stat-value">{employeeStats.total}</span>
                <span className="stat-label">{t('totalEmployees')}</span>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">🔄</div>
              <div className="stat-info">
                <span className="stat-value">{employeeStats.testing}</span>
                <span className="stat-label">{t('testingPeriod')}</span>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">❌</div>
              <div className="stat-info">
                <span className="stat-value">{employeeStats.fired}</span>
                <span className="stat-label">{t('fired')}</span>
              </div>
            </div>
            <div className="stat-card">
              <div className="stat-icon">🏖️</div>
              <div className="stat-info">
                <span className="stat-value">{employeeStats.vacation}</span>
                <span className="stat-label">{t('onVacation')}</span>
              </div>
            </div>
          </div>

          {/* Employee Shortage Requests Section */}
          {employeeShortageRequests.length > 0 && (
            <div className="hr-shortage-section">
              <h3>{t('employeeShortageRequests')}</h3>
              <div className="shortage-requests-list">
                {employeeShortageRequests.map(req => (
                  <div key={req.id} className={`shortage-request-item ${req.status}`}>
                    <div className="shortage-info">
                      <span className="shortage-id">{req.id}</span>
                      <span className="shortage-store">{req.storeName}</span>
                      <span className="shortage-role">{req.role}</span>
                      <span className="shortage-amount">×{req.amount}</span>
                      <span className="shortage-needed">by {req.neededBy}</span>
                      {req.hasFiles && <span className="shortage-files">📎</span>}
                      <span className={`shortage-status ${req.status}`}>{req.status}</span>
                    </div>
                    {req.status === 'pending' && (
                      <div className="shortage-actions">
                        <input
                          type="text"
                          placeholder={t('addComment')}
                          value={shortageComment[req.id] || ''}
                          onChange={e => setShortageComment({...shortageComment, [req.id]: e.target.value})}
                          className="comment-input"
                        />
                        <button className="deny-btn" onClick={() => handleShortageRequest(req.id, false)}>{t('deny')}</button>
                        <button className="approve-btn" onClick={() => handleShortageRequest(req.id, true)}>{t('approve')}</button>
                      </div>
                    )}
                    {req.comment && (
                      <div className="request-comment">{t('comment')}: {req.comment}</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="hr-middle-section">
            <div className="hr-requests">
              <h3>{t('activeRequests')}</h3>
              <div className="requests-list-hr">
                {activeRequests.map(req => (
                  <div key={req.id} className={`request-item-hr ${req.status}`}>
                    <div className="request-header-hr">
                      <span className="request-id-hr">{req.id}</span>
                      <span className={`request-status-hr ${req.status}`}>{req.status}</span>
                    </div>
                    <div className="request-body-hr">
                      <span className="employee-name">{req.employee}</span>
                      <span className="request-type">{req.type}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="hr-second-page-btn">
              <button onClick={() => setShowSecondPage(true)}>
                {t('approveCandidates')}
              </button>
            </div>

            <div className="hr-notifications">
              <h3>{t('notifications')}</h3>
              <div className="notifications-scroll">
                {hrNotifications.map(notif => (
                  <div key={notif.id} className="notification-item-hr">
                    <div className="notif-header-hr">
                      <span className="notif-from-hr">{notif.from}</span>
                      <span className="notif-date-hr">{notif.date}</span>
                    </div>
                    <div className="notif-message-hr">{notif.message}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="hr-second-page">
          <button className="back-btn" onClick={() => setShowSecondPage(false)}>
            {t('backDashboard')}
          </button>

          <div className="hr-second-content">
            <div className="incidents-section">
              <h3>{t('complaintsIncidents')}</h3>
              <div className="incidents-list">
                {incidents.filter(i => i.type === 'client-related' || i.type === 'employee').map(incident => (
                  <div 
                    key={incident.id}
                    className={`incident-item ${selectedIncident?.id === incident.id ? 'selected' : ''}`}
                    onClick={() => setSelectedIncident(incident)}
                  >
                    <div className="incident-header">
                      <span className="incident-id">{incident.id}</span>
                      <span className={`incident-priority ${incident.priority}`}>{incident.priority}</span>
                    </div>
                    <div className="incident-client">{incident.clientName}</div>
                    <div className="incident-desc">{incident.description}</div>
                    <div className="incident-footer">
                      <span className="incident-status">{incident.status}</span>
                      <span className="incident-date">{incident.date}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="trainings-section">
              <h3>{t('plannedTrainings')}</h3>
              <table className="trainings-table">
                <thead>
                  <tr>
                    <th>{t('date')}</th>
                    <th>{t('theme')}</th>
                    <th>{t('participants')}</th>
                    <th>{t('status')}</th>
                    <th>{t('rating')}</th>
                  </tr>
                </thead>
                <tbody>
                  {trainings.map(t => (
                    <tr key={t.id}>
                      <td>{t.date}</td>
                      <td>{t.theme}</td>
                      <td>{t.participants}</td>
                      <td>
                        <span className={`status-badge ${t.status}`}>{t.status}</span>
                      </td>
                      <td>{t.rating ? `⭐ ${t.rating}` : '-'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {selectedIncident && (
            <div className="incident-detail-panel">
              <h4>{t('incidentDetails')} - {selectedIncident.id}</h4>
              <div className="detail-section">
                <h5>{t('historyChanges')}</h5>
                <div className="history-list">
                  {selectedIncident.history.map((h, i) => (
                    <div key={i} className="history-item">
                      <span className="history-date">{h.date}</span>
                      <span className="history-action">{h.action}</span>
                      <span className="history-by">by {h.by}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="detail-section">
                <h5>{t('detailedDescription')}</h5>
                <p>{selectedIncident.detailedDescription}</p>
              </div>
              <div className="detail-section">
                <h5>{t('assignEmployee')}</h5>
                <select 
                  value={selectedEmployee} 
                  onChange={e => setSelectedEmployee(e.target.value)}
                >
                  <option value="">{t('selectEmployee')}</option>
                  {employees.filter(e => e.status === 'active').map(e => (
                    <option key={e.id} value={e.name}>{e.name} - {e.position}</option>
                  ))}
                </select>
              </div>
              <div className="incident-actions">
                <button className="close-incident-btn" onClick={handleCloseIncident}>
                  {t('closeIncident')}
                </button>
                <button className="assign-btn" onClick={handleAssignIncident} disabled={!selectedEmployee}>
                  {t('assign')}
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Client Page
function ClientPage() {
  const { orders, products, updateState } = useAppState();
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [bonusBalance] = useState(2450);
  const [useBonuses, setUseBonuses] = useState(false);

  const banners = [
    { id: 1, title: 'Fresh Organic Products', subtitle: 'Up to 30% off', color: '#4CAF50' },
    { id: 2, title: 'Weekend Special', subtitle: 'Buy 2 Get 1 Free', color: '#2196F3' },
    { id: 3, title: 'New Arrivals', subtitle: 'Premium Selection', color: '#9C27B0' },
  ];

  const quickLinks = [
    { icon: '🛒', label: t('cart'), count: 3 },
    { icon: '📜', label: t('orderHistory') },
    { icon: '❤️', label: t('favorites') },
    { icon: '🏷️', label: t('coupons') },
    { icon: '⚙️', label: t('settings') },
  ];

  const recommendations = [
    { id: 1, name: 'Organic Green Tea', price: 12.99, desc: 'Premium Japanese green tea leaves', image: '🍵' },
    { id: 2, name: 'Manuka Honey', price: 24.99, desc: 'Raw organic honey from New Zealand', image: '🍯' },
    { id: 3, name: 'Almond Butter', price: 9.99, desc: 'Creamy roasted almond spread', image: '🥜' },
    { id: 4, name: 'Coconut Water', price: 3.49, desc: 'Natural hydration from young coconuts', image: '🥥' },
  ];

  const orderNotifications = [
    { id: 1, message: 'Order ORD-001 is on its way!', time: '2 hours ago' },
    { id: 2, message: 'Order ORD-002 has been delivered', time: '1 day ago' },
    { id: 3, message: 'Your refund for ORD-005 has been processed', time: '3 days ago' },
  ];

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const finalTotal = useBonuses ? Math.max(0, cartTotal - bonusBalance * 0.01) : cartTotal;

  const addToCart = (product: Product) => {
    const existing = cart.find(c => c.product.id === product.id);
    if (existing) {
      setCart(cart.map(c => c.product.id === product.id ? { ...c, quantity: c.quantity + 1 } : c));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
  };

  const handlePlaceOrder = () => {
    if (cart.length > 0) {
      const newOrder: Order = {
        id: `ORD-${String(orders.length + 1).padStart(3, '0')}`,
        date: new Date().toISOString().split('T')[0],
        price: finalTotal,
        status: 'on the way',
        items: cart.map(c => ({ name: c.product.name, quantity: c.quantity, price: c.product.price }))
      };
      updateState('orders', [newOrder, ...orders]);
      setCart([]);
      setShowOrderModal(false);
      setUseBonuses(false);
    }
  };

  const handleOrderAction = (action: string, order: Order) => {
    const updated = orders.map(o => {
      if (o.id === order.id) {
        switch (action) {
          case 'cancel': return { ...o, status: 'cancelled' as const };
          case 'refund': return { ...o, status: 'refunded' as const };
          case 'reorder':
            const newOrder: Order = {
              id: `ORD-${String(orders.length + 1).padStart(3, '0')}`,
              date: new Date().toISOString().split('T')[0],
              price: o.price,
              status: 'on the way',
              items: o.items
            };
            updateState('orders', [newOrder, ...orders]);
            return o;
        }
      }
      return o;
    });
    updateState('orders', updated);
  };

  const getStatusText = (status: string) => {
    switch(status) {
      case 'on the way': return t('onTheWay');
      case 'delivered': return t('delivered');
      case 'returned': return t('returned');
      case 'refunded': return t('refunded');
      case 'late': return t('late');
      case 'cancelled': return t('cancelled');
      default: return status;
    }
  };

  return (
    <div className="client-page">
      <div className="client-top-section">
        <div className="search-section">
          <input
            type="text"
            className="search-bar"
            placeholder={t('searchProducts')}
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="bonus-balance">
          <span className="bonus-icon">🎁</span>
          <div className="bonus-info">
            <span className="bonus-label">{t('bonusBalance')}</span>
            <span className="bonus-value">{bonusBalance} {t('pts')}</span>
          </div>
        </div>
      </div>

      <div className="banners-section">
        {banners.map(banner => (
          <div key={banner.id} className="banner" style={{ background: `linear-gradient(135deg, ${banner.color}, ${banner.color}dd)` }}>
            <div className="banner-content">
              <h3>{banner.title}</h3>
              <p>{banner.subtitle}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="client-middle-section">
        <div className="quick-links-section">
          <h3>{t('quickLinks')}</h3>
          <div className="quick-links-grid">
            {quickLinks.map((link, i) => (
              <button key={i} className="quick-link-btn">
                <span className="link-icon">{link.icon}</span>
                <span className="link-label">{link.label}</span>
                {link.count && <span className="link-count">{link.count}</span>}
              </button>
            ))}
          </div>
        </div>

        <div className="recommendations-section">
          <h3>{t('recommended')}</h3>
          <div className="recommendations-grid">
            {recommendations.map(rec => (
              <div key={rec.id} className="recommendation-card">
                <div className="rec-image">{rec.image}</div>
                <div className="rec-info">
                  <h4>{rec.name}</h4>
                  <p>{rec.desc}</p>
                  <div className="rec-footer">
                    <span className="rec-price">${rec.price.toFixed(2)}</span>
                    <button className="add-to-cart-btn" onClick={() => addToCart(products.find(p => p.name.includes(rec.name.split(' ')[0])) || products[0])}>
                      {t('addToCart')}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="notifications-scroll-section">
        <h3>{t('orderUpdates')}</h3>
        <div className="order-notifications">
          {orderNotifications.map(notif => (
            <div key={notif.id} className="order-notif-item">
              <span className="notif-message">{notif.message}</span>
              <span className="notif-time">{notif.time}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="orders-section">
        <div className="orders-table-section">
          <h3>{t('myOrders')}</h3>
          <table className="orders-table">
            <thead>
              <tr>
                <th>{t('orderId')}</th>
                <th>{t('date')}</th>
                <th>{t('price')}</th>
                <th>{t('status')}</th>
                <th>{t('actions')}</th>
              </tr>
            </thead>
            <tbody>
              {orders.map(order => (
                <tr 
                  key={order.id}
                  className={selectedOrder?.id === order.id ? 'selected' : ''}
                  onClick={() => setSelectedOrder(order)}
                >
                  <td>{order.id}</td>
                  <td>{order.date}</td>
                  <td>${order.price.toFixed(2)}</td>
                  <td>
                    <span className={`status-badge order-status ${order.status.replace(' ', '-')}`}>
                      {getStatusText(order.status)}
                    </span>
                  </td>
                  <td>
                    <div className="order-actions">
                      {order.status === 'on the way' && (
                        <button onClick={(e) => { e.stopPropagation(); handleOrderAction('cancel', order); }}>{t('cancel')}</button>
                      )}
                      {order.status === 'delivered' && (
                        <button onClick={(e) => { e.stopPropagation(); handleOrderAction('reorder', order); }}>{t('reorder')}</button>
                      )}
                      {(order.status === 'on the way' || order.status === 'late') && (
                        <button onClick={(e) => { e.stopPropagation(); handleOrderAction('refund', order); }}>{t('refund')}</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="new-order-btn" onClick={() => setShowOrderModal(true)}>
            {t('createNewOrder')}
          </button>
        </div>

        <div className="order-details-section">
          <h3>{t('orderDetails')}</h3>
          {selectedOrder ? (
            <div className="selected-order-details">
              <div className="detail-row">
                <span>{t('orderId')}:</span>
                <span>{selectedOrder.id}</span>
              </div>
              <div className="detail-row">
                <span>{t('status')}:</span>
                <span className={`status-badge ${selectedOrder.status}`}>{getStatusText(selectedOrder.status)}</span>
              </div>
              <div className="detail-row">
                <span>{t('estimatedArrival')}:</span>
                <span>{selectedOrder.status === 'delivered' ? t('delivered') : '2-3 business days'}</span>
              </div>
              <div className="order-items">
                <h4>{t('items')}:</h4>
                {selectedOrder.items.map((item, i) => (
                  <div key={i} className="order-item">
                    <span>{item.name} × {item.quantity}</span>
                    <span>${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              {selectedOrder.status === 'delivered' && (
                <div className="review-section">
                  <h4>{t('leaveReview')}</h4>
                  <div className="star-rating">
                    {[1, 2, 3, 4, 5].map(star => (
                      <span key={star} className="star">⭐</span>
                    ))}
                  </div>
                  <textarea placeholder="Write your review..."></textarea>
                  <button>{t('submitReview')}</button>
                </div>
              )}
              {selectedOrder.status === 'refunded' && (
                <div className="refund-form">
                  <h4>{t('refundInfo')}</h4>
                  <p>{t('refundInfo')}: ${selectedOrder.price.toFixed(2)}</p>
                  <p>Expected in 3-5 business days.</p>
                </div>
              )}
            </div>
          ) : (
            <div className="no-order-selected">
              <p>{t('selectOrder')}</p>
            </div>
          )}
        </div>
      </div>

      {showOrderModal && (
        <div className="modal-overlay" onClick={() => setShowOrderModal(false)}>
          <div className="modal-content order-modal" onClick={e => e.stopPropagation()}>
            <h3>{t('createNewOrder')}</h3>
            <div className="product-catalog">
              <h4>{t('availableProducts')}</h4>
              <div className="catalog-grid">
                {filteredProducts.map(product => (
                  <div key={product.id} className="catalog-item">
                    <div className="catalog-item-info">
                      <span className="catalog-item-name">{product.name}</span>
                      <span className="catalog-item-category">{product.category}</span>
                      <span className="catalog-item-price">${product.price.toFixed(2)}</span>
                    </div>
                    <button 
                      className="add-to-cart-btn"
                      onClick={() => addToCart(product)}
                    >
                      {t('addToCart')}
                    </button>
                  </div>
                ))}
              </div>
            </div>
            <div className="cart-summary">
              <h4>{t('yourCart')}</h4>
              {cart.length > 0 ? (
                <>
                  {cart.map((item, i) => (
                    <div key={i} className="cart-item">
                      <span>{item.product.name} × {item.quantity}</span>
                      <span>${(item.product.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="bonus-toggle">
                    <label>
                      <input
                        type="checkbox"
                        checked={useBonuses}
                        onChange={e => setUseBonuses(e.target.checked)}
                      />
                      {t('useBonus')} {bonusBalance} {t('bonusPoints')} (${(bonusBalance * 0.01).toFixed(2)} value)
                    </label>
                  </div>
                  <div className="cart-total">
                    <span>{t('total')}</span>
                    <span>${finalTotal.toFixed(2)}</span>
                  </div>
                  <div className="payment-section">
                    <h5>{t('paymentInfo')}</h5>
                    <div className="fake-card">
                      <div className="card-number">•••• •••• •••• 4242</div>
                      <div className="card-details">
                        <span>EXP: 12/26</span>
                        <span>CVV: •••</span>
                      </div>
                    </div>
                  </div>
                  <button className="place-order-btn" onClick={handlePlaceOrder}>
                    {t('placeOrder')}
                  </button>
                </>
              ) : (
                <p className="empty-cart">{t('emptyCart')}</p>
              )}
            </div>
            <button className="close-modal-btn" onClick={() => setShowOrderModal(false)}>{t('close')}</button>
          </div>
        </div>
      )}
    </div>
  );
}

// Product Manager Page
function ProductManagerPage() {
  const { tasks, products, incidents, notifications, orderRequests, updateState } = useAppState();
  const { t } = useLanguage();
  const [localTasks, setLocalTasks] = useState<Task[]>(tasks);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [reportSent, setReportSent] = useState(false);
  const [hoveredIncident, setHoveredIncident] = useState<Incident | null>(null);
  const [newTask, setNewTask] = useState('');
  const [orderProduct, setOrderProduct] = useState('');
  const [orderAmount, setOrderAmount] = useState(1);
  const [newIncident, setNewIncident] = useState({
    type: 'technical',
    clientName: '',
    description: '',
    detailedDescription: '',
    hasFiles: false,
  });

  const lowStockProducts = products.filter(p => p.amount < 5);
  const allTasksDone = localTasks.every(t => t.completed);

  const handleTaskToggle = (taskId: string) => {
    const updated = localTasks.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          completed: !t.completed,
          completedDate: !t.completed ? new Date().toISOString().split('T')[0] : undefined
        };
      }
      return t;
    });
    setLocalTasks(updated);
    updateState('tasks', updated);
  };

  const handleAddTask = () => {
    if (newTask.trim()) {
      const task: Task = {
        id: `T-${String(localTasks.length + 1).padStart(3, '0')}`,
        text: newTask,
        completed: false,
        isMandatory: false
      };
      setLocalTasks([...localTasks, task]);
      setNewTask('');
    }
  };

  const handleRemoveTask = (taskId: string) => {
    const task = localTasks.find(t => t.id === taskId);
    if (task && !task.isMandatory) {
      setLocalTasks(localTasks.filter(t => t.id !== taskId));
    }
  };

  const handleSendReport = () => {
    if (allTasksDone) {
      const reportNotif: Notification = {
        id: `N-${Date.now()}`,
        from: 'Product Manager',
        message: `Daily Report: ${localTasks.filter(t => t.completed).length} tasks completed, ${lowStockProducts.length} products need restocking`,
        type: 'info',
        date: new Date().toISOString().split('T')[0],
        read: false
      };
      updateState('notifications', [reportNotif, ...notifications]);
      setReportSent(true);
      setTimeout(() => setReportSent(false), 3000);
    }
  };

  const handleOrderProduct = () => {
    if (orderProduct && orderAmount > 0) {
      const request: OrderRequest = {
        id: `REQ-${Date.now()}`,
        storeName: 'Downtown Store',
        productName: orderProduct,
        amount: orderAmount,
        status: 'pending',
        initialDate: new Date().toISOString().split('T')[0]
      };
      updateState('orderRequests', [request, ...orderRequests]);
      setShowOrderModal(false);
      setOrderProduct('');
      setOrderAmount(1);
    }
  };

  const handleRegisterIncident = () => {
    if (newIncident.description) {
      const incident: Incident = {
        id: `INC-${String(incidents.length + 1).padStart(3, '0')}`,
        type: newIncident.type,
        clientName: newIncident.clientName || 'N/A',
        description: newIncident.description,
        detailedDescription: newIncident.detailedDescription,
        status: 'open',
        priority: 'medium',
        date: new Date().toISOString().split('T')[0],
        history: [{ date: new Date().toISOString().split('T')[0], action: 'Incident registered', by: 'Product Manager' }]
      };
      updateState('incidents', [incident, ...incidents]);

      const notifTarget = newIncident.type === 'client-related' ? 'HR Specialist' : 'Store Manager';
      const notif: Notification = {
        id: `N-${Date.now()}`,
        from: 'Product Manager',
        message: `New ${newIncident.type} incident: ${newIncident.description}`,
        type: 'warning',
        date: new Date().toISOString().split('T')[0],
        read: false
      };
      updateState('notifications', [notif, ...notifications]);
      
      setNewIncident({ type: 'technical', clientName: '', description: '', detailedDescription: '', hasFiles: false });
    }
  };

  const monthlyIncidents = incidents.filter(i => {
    const incidentDate = new Date(i.date);
    const now = new Date();
    return incidentDate.getMonth() === now.getMonth() && incidentDate.getFullYear() === now.getFullYear();
  });

  const getIncidentTypeText = (type: string) => {
    switch(type) {
      case 'technical': return t('technical');
      case 'client-related': return t('clientRelated');
      case 'product': return t('product');
      case 'employee': return t('employee');
      default: return type;
    }
  };

  return (
    <div className="product-manager-page">
      <div className="pm-top-section">
        <div className="todo-section">
          <h3>{t('todoList')}</h3>
          <div className="todo-list">
            {localTasks.map(task => (
              <div key={task.id} className={`todo-item ${task.completed ? 'completed' : ''}`}>
                <label className="todo-checkbox">
                  <input
                    type="checkbox"
                    checked={task.completed}
                    onChange={() => handleTaskToggle(task.id)}
                  />
                  <span className="checkmark"></span>
                </label>
                <span className="todo-text">{task.text}</span>
                {task.completed && task.completedDate && (
                  <span className="completed-date">{task.completedDate}</span>
                )}
                {!task.isMandatory && (
                  <button className="remove-task-btn" onClick={() => handleRemoveTask(task.id)}>×</button>
                )}
                {task.isMandatory && <span className="mandatory-badge">{t('required')}</span>}
              </div>
            ))}
          </div>
          <div className="add-task-section">
            <input
              type="text"
              placeholder={t('addTaskPlaceholder')}
              value={newTask}
              onChange={e => setNewTask(e.target.value)}
              onKeyPress={e => e.key === 'Enter' && handleAddTask()}
            />
            <button onClick={handleAddTask}>{t('addTask')}</button>
          </div>
        </div>

        <div className="pm-actions-section">
          <button 
            className={`send-report-btn ${allTasksDone ? 'active' : 'disabled'}`}
            disabled={!allTasksDone}
            onClick={handleSendReport}
          >
            {t('sendReport')}
          </button>
          {reportSent && <div className="report-sent-msg">{t('reportSent')}</div>}
          
          <button className="order-products-btn" onClick={() => setShowOrderModal(true)}>
            {t('orderProducts')}
          </button>
        </div>
      </div>

      <div className="pm-middle-section">
        <div className="low-stock-section">
          <h3>{t('lowStock')}</h3>
          <div className="low-stock-list">
            {lowStockProducts.map(product => (
              <div key={product.id} className="low-stock-item">
                <div className="product-info">
                  <span className="product-name">{product.name}</span>
                  <span className="product-category">{product.category}</span>
                </div>
                <div className="stock-info">
                  <span className={`stock-count ${product.amount <= 2 ? 'critical' : 'warning'}`}>
                    {product.amount} {t('left')}
                  </span>
                  <span className="product-price">${product.price.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="incident-form-section">
          <h3>{t('registerIncident')}</h3>
          <div className="incident-form">
            <div className="form-row">
              <label>{t('incidentType')}</label>
              <select 
                value={newIncident.type}
                onChange={e => setNewIncident({...newIncident, type: e.target.value})}
              >
                <option value="technical">{t('technical')}</option>
                <option value="product">{t('product')}</option>
                <option value="employee">{t('employee')}</option>
                <option value="client-related">{t('clientRelated')}</option>
              </select>
            </div>
            <div className="form-row">
              <label>{t('clientNameSurname')}</label>
              <input
                type="text"
                placeholder={t('enterClientName')}
                value={newIncident.clientName}
                onChange={e => setNewIncident({...newIncident, clientName: e.target.value})}
              />
            </div>
            <div className="form-row">
              <label>{t('shortDescription')}</label>
              <input
                type="text"
                placeholder={t('briefDescription')}
                value={newIncident.description}
                onChange={e => setNewIncident({...newIncident, description: e.target.value})}
              />
            </div>
            <div className="form-row">
              <label>{t('detailedDescription')}</label>
              <textarea
                placeholder={t('fullDetails')}
                value={newIncident.detailedDescription}
                onChange={e => setNewIncident({...newIncident, detailedDescription: e.target.value})}
              ></textarea>
            </div>
            <div className="form-row">
              <button className="attach-btn" onClick={() => setNewIncident({...newIncident, hasFiles: !newIncident.hasFiles})}>
                {t('attachFiles')} {newIncident.hasFiles ? '✓' : ''}
              </button>
            </div>
            <button className="register-incident-btn" onClick={handleRegisterIncident}>
              {t('registerIncidentBtn')}
            </button>
          </div>
        </div>
      </div>

      <div className="pm-bottom-section">
        <div className="incident-history-section">
          <h3>{t('incidentHistory')}</h3>
          <div className="incident-history-list">
            {monthlyIncidents.map(incident => (
              <div 
                key={incident.id}
                className="incident-history-item"
                onMouseEnter={() => setHoveredIncident(incident)}
                onMouseLeave={() => setHoveredIncident(null)}
              >
                <span className="incident-id">{incident.id}</span>
                <span className="incident-desc">{incident.description}</span>
                <span className="incident-date">{incident.date}</span>
                <span className={`incident-status ${incident.status}`}>{incident.status === 'open' ? t('open') : incident.status === 'resolved' ? t('resolved') : t('inProgress')}</span>
              </div>
            ))}
          </div>
        </div>

        {hoveredIncident && (
          <div className="incident-details-popup">
            <h4>{t('incidentDetails')}</h4>
            <div className="detail-row">
              <span>ID:</span>
              <span>{hoveredIncident.id}</span>
            </div>
            <div className="detail-row">
              <span>{t('incidentType')}:</span>
              <span>{getIncidentTypeText(hoveredIncident.type)}</span>
            </div>
            <div className="detail-row">
              <span>{t('status')}:</span>
              <span>{hoveredIncident.status}</span>
            </div>
            <div className="detail-row">
              <span>{t('priority')}:</span>
              <span>{hoveredIncident.priority}</span>
            </div>
            <div className="detail-row">
              <span>{t('clientNameSurname')}:</span>
              <span>{hoveredIncident.clientName}</span>
            </div>
            <div className="detail-section">
              <span>{t('detailedDescription')}:</span>
              <p>{hoveredIncident.detailedDescription}</p>
            </div>
          </div>
        )}
      </div>

      {showOrderModal && (
        <div className="modal-overlay" onClick={() => setShowOrderModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h3>{t('orderProducts')}</h3>
            <div className="form-group">
              <label>{t('product')}</label>
              <select value={orderProduct} onChange={e => setOrderProduct(e.target.value)}>
                <option value="">{t('selectProduct')}</option>
                {products.map(p => (
                  <option key={p.id} value={p.name}>{p.name} - ${p.price.toFixed(2)}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>{t('amount')}</label>
              <input 
                type="number" 
                min="1" 
                value={orderAmount}
                onChange={e => setOrderAmount(parseInt(e.target.value) || 1)}
              />
            </div>
            <div className="modal-actions">
              <button className="cancel-btn" onClick={() => setShowOrderModal(false)}>{t('cancel')}</button>
              <button className="confirm-btn" onClick={handleOrderProduct}>{t('sendRequest')}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
